<?php

namespace App\Enums;

enum PipelineEnum: string
{
    case LEAD = 'Lead';
    case VIEWING = 'Viewing';
    case BOOKING = 'Booking';
    case SPA_SIGNED = 'SPA Signed';
    case LOAN_SUBMITTED = 'Loan Submitted';
    case LOAN_APPROVED = 'Loan Approved';
    case LEGAL_PROCESSING = 'Legal Processing';
    case COMPLETED = 'Completed';
    case COMMISSION_PAID = 'Commission Paid';

    /**
     * Badge color classes
     */
    public function color(): string
    {
        return match ($this) {
            self::LEAD => 'bg-gray-100 text-gray-800 text-xs',
            self::VIEWING => 'bg-blue-100 text-blue-800 text-xs',
            self::BOOKING => 'bg-yellow-100 text-yellow-800 text-xs',
            self::SPA_SIGNED => 'bg-purple-100 text-purple-800 text-xs',
            self::LOAN_SUBMITTED => 'bg-orange-100 text-orange-800 text-xs',
            self::LOAN_APPROVED => 'bg-green-100 text-green-800 text-xs',
            self::LEGAL_PROCESSING => 'bg-indigo-100 text-indigo-800 text-xs',
            self::COMPLETED => 'bg-emerald-100 text-emerald-800 text-xs',
            self::COMMISSION_PAID => 'bg-teal-100 text-teal-800 text-xs',
        };
    }

    /**
     * Badge style (optional future use)
     */
    public function badge(): string
    {
        return 'px-2 py-1 font-semibold rounded-full '.$this->color();
    }

    /**
     * Get all enum values
     */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    /**
     * Stages that can be manually selected during deal creation.
     */
    public static function creatableCases(): array
    {
        return [
            self::LEAD,
            self::VIEWING,
            self::BOOKING,
            self::SPA_SIGNED,
        ];
    }

    public static function creatableValues(): array
    {
        return array_column(self::creatableCases(), 'value');
    }

    /**
     * Stages that are system-driven and should no longer be manually edited.
     */
    public static function lockedCases(): array
    {
        return [
            self::LOAN_SUBMITTED,
            self::LOAN_APPROVED,
            self::LEGAL_PROCESSING,
            self::COMPLETED,
            self::COMMISSION_PAID,
        ];
    }

    public static function loanStages(): array
    {
        return [
            self::BOOKING->value,
            self::SPA_SIGNED->value,
            self::LOAN_SUBMITTED->value,
            self::LOAN_APPROVED->value,
            self::LEGAL_PROCESSING->value,
            self::COMPLETED->value,
            self::COMMISSION_PAID->value,
        ];
    }

    public function isLockedForManualEdit(): bool
    {
        return in_array($this, self::lockedCases(), true);
    }
}
