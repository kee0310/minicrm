import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import approvalAnalysisD7e211 from './approval-analysis'
import bankSubmissionTrackingEef084 from './bank-submission-tracking'
import borrowerProfile399597 from './borrower-profile'
import detail30d213 from './detail'
import disbursement6ab1e3 from './disbursement'
import preQualification079571 from './pre-qualification'
/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
export const notifications = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: notifications.url(options),
    method: 'get',
})

notifications.definition = {
    methods: ["get","head"],
    url: '/loans/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
notifications.url = (options?: RouteQueryOptions) => {
    return notifications.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
notifications.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: notifications.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
notifications.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: notifications.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
    const notificationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: notifications.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
        notificationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: notifications.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
        notificationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: notifications.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    notifications.form = notificationsForm
/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
export const borrowerProfile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: borrowerProfile.url(options),
    method: 'get',
})

borrowerProfile.definition = {
    methods: ["get","head"],
    url: '/loans/borrower-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
borrowerProfile.url = (options?: RouteQueryOptions) => {
    return borrowerProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
borrowerProfile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: borrowerProfile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
borrowerProfile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: borrowerProfile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
    const borrowerProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: borrowerProfile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
        borrowerProfileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: borrowerProfile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
        borrowerProfileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: borrowerProfile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    borrowerProfile.form = borrowerProfileForm
/**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
export const detail = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detail.url(args, options),
    method: 'get',
})

detail.definition = {
    methods: ["get","head"],
    url: '/loans/detail/{deal}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
detail.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return detail.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
detail.get = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
detail.head = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
    const detailForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: detail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
        detailForm.get = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: detail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::detail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
        detailForm.head = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: detail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    detail.form = detailForm
/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
export const preQualification = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preQualification.url(options),
    method: 'get',
})

preQualification.definition = {
    methods: ["get","head"],
    url: '/loans/pre-qualification',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
preQualification.url = (options?: RouteQueryOptions) => {
    return preQualification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
preQualification.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preQualification.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
preQualification.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preQualification.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
    const preQualificationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preQualification.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
        preQualificationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preQualification.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
        preQualificationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preQualification.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preQualification.form = preQualificationForm
/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
export const bankSubmissionTracking = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankSubmissionTracking.url(options),
    method: 'get',
})

bankSubmissionTracking.definition = {
    methods: ["get","head"],
    url: '/loans/bank-submission-tracking',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
bankSubmissionTracking.url = (options?: RouteQueryOptions) => {
    return bankSubmissionTracking.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
bankSubmissionTracking.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankSubmissionTracking.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
bankSubmissionTracking.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bankSubmissionTracking.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
    const bankSubmissionTrackingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bankSubmissionTracking.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
        bankSubmissionTrackingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankSubmissionTracking.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
        bankSubmissionTrackingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankSubmissionTracking.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bankSubmissionTracking.form = bankSubmissionTrackingForm
/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
export const approvalAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvalAnalysis.url(options),
    method: 'get',
})

approvalAnalysis.definition = {
    methods: ["get","head"],
    url: '/loans/approval-analysis',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
approvalAnalysis.url = (options?: RouteQueryOptions) => {
    return approvalAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
approvalAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvalAnalysis.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
approvalAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: approvalAnalysis.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
    const approvalAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: approvalAnalysis.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
        approvalAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: approvalAnalysis.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
        approvalAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: approvalAnalysis.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    approvalAnalysis.form = approvalAnalysisForm
/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
export const disbursement = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: disbursement.url(options),
    method: 'get',
})

disbursement.definition = {
    methods: ["get","head"],
    url: '/loans/disbursement',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
disbursement.url = (options?: RouteQueryOptions) => {
    return disbursement.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
disbursement.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: disbursement.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
disbursement.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: disbursement.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
    const disbursementForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: disbursement.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
        disbursementForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: disbursement.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
        disbursementForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: disbursement.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    disbursement.form = disbursementForm
const loans = {
    notifications: Object.assign(notifications, notifications),
borrowerProfile: Object.assign(borrowerProfile, borrowerProfile399597),
detail: Object.assign(detail, detail30d213),
preQualification: Object.assign(preQualification, preQualification079571),
bankSubmissionTracking: Object.assign(bankSubmissionTracking, bankSubmissionTrackingEef084),
approvalAnalysis: Object.assign(approvalAnalysis, approvalAnalysisD7e211),
disbursement: Object.assign(disbursement, disbursement6ab1e3),
}

export default loans