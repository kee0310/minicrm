import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\LoanController::store
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
export const store = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/loans/approval-analysis/{deal}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoanController::store
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
store.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return store.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::store
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
store.post = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LoanController::store
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
    const storeForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::store
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
        storeForm.post = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\LoanController::update
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
export const update = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/loans/approval-analysis/{deal}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::update
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
update.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return update.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::update
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
update.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LoanController::update
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
    const updateForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::update
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
        updateForm.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const approvalAnalysis = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
}

export default approvalAnalysis