import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
export const byLoan = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byLoan.url(args, options),
    method: 'get',
})

byLoan.definition = {
    methods: ["get","head"],
    url: '/loans/detail/by-loan/{loanId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
byLoan.url = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loanId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loanId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loanId: args.loanId,
                }

    return byLoan.definition.url
            .replace('{loanId}', parsedArgs.loanId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
byLoan.get = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: byLoan.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
byLoan.head = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: byLoan.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
    const byLoanForm = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: byLoan.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
        byLoanForm.get = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byLoan.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::byLoan
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
        byLoanForm.head = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: byLoan.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    byLoan.form = byLoanForm
const detail = {
    byLoan: Object.assign(byLoan, byLoan),
}

export default detail