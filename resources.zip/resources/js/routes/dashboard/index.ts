import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::index
 * @see app/Http/Controllers/DashboardController.php:20
 * @route '/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
export const charts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: charts.url(options),
    method: 'get',
})

charts.definition = {
    methods: ["get","head"],
    url: '/dashboard/charts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
charts.url = (options?: RouteQueryOptions) => {
    return charts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
charts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: charts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
charts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: charts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
    const chartsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: charts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
        chartsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: charts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
        chartsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: charts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    charts.form = chartsForm
/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
export const pipelineDetails = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pipelineDetails.url(options),
    method: 'get',
})

pipelineDetails.definition = {
    methods: ["get","head"],
    url: '/dashboard/pipeline-details',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
pipelineDetails.url = (options?: RouteQueryOptions) => {
    return pipelineDetails.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
pipelineDetails.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pipelineDetails.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
pipelineDetails.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pipelineDetails.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
    const pipelineDetailsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pipelineDetails.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
        pipelineDetailsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pipelineDetails.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
        pipelineDetailsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pipelineDetails.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pipelineDetails.form = pipelineDetailsForm
/**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
export const sales = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales.url(options),
    method: 'get',
})

sales.definition = {
    methods: ["get","head"],
    url: '/dashboard/sales',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
sales.url = (options?: RouteQueryOptions) => {
    return sales.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
sales.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
sales.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sales.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
    const salesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sales.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
        salesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sales.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::sales
 * @see app/Http/Controllers/DashboardController.php:40
 * @route '/dashboard/sales'
 */
        salesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sales.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sales.form = salesForm
/**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
export const deals = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deals.url(options),
    method: 'get',
})

deals.definition = {
    methods: ["get","head"],
    url: '/dashboard/deals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
deals.url = (options?: RouteQueryOptions) => {
    return deals.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
deals.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: deals.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
deals.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: deals.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
    const dealsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: deals.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
        dealsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: deals.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::deals
 * @see app/Http/Controllers/DashboardController.php:45
 * @route '/dashboard/deals'
 */
        dealsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: deals.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    deals.form = dealsForm
/**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
export const salespeople = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: salespeople.url(options),
    method: 'get',
})

salespeople.definition = {
    methods: ["get","head"],
    url: '/dashboard/salespeople',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
salespeople.url = (options?: RouteQueryOptions) => {
    return salespeople.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
salespeople.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: salespeople.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
salespeople.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: salespeople.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
    const salespeopleForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: salespeople.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
        salespeopleForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: salespeople.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardController::salespeople
 * @see app/Http/Controllers/DashboardController.php:50
 * @route '/dashboard/salespeople'
 */
        salespeopleForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: salespeople.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    salespeople.form = salespeopleForm
const dashboard = {
    index: Object.assign(index, index),
charts: Object.assign(charts, charts),
pipelineDetails: Object.assign(pipelineDetails, pipelineDetails),
sales: Object.assign(sales, sales),
deals: Object.assign(deals, deals),
salespeople: Object.assign(salespeople, salespeople),
}

export default dashboard