import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
export const count = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: count.url(options),
    method: 'get',
})

count.definition = {
    methods: ["get","head"],
    url: '/notifications/count',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
count.url = (options?: RouteQueryOptions) => {
    return count.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
count.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: count.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
count.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: count.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
    const countForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: count.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
        countForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: count.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:38
 * @route '/notifications/count'
 */
        countForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: count.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    count.form = countForm
const notifications = {
    count: Object.assign(count, count),
}

export default notifications