import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/deals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DealController::index
 * @see app/Http/Controllers/DealController.php:19
 * @route '/deals'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:86
 * @route '/deals'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/deals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:86
 * @route '/deals'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:86
 * @route '/deals'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:86
 * @route '/deals'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::store
 * @see app/Http/Controllers/DealController.php:86
 * @route '/deals'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
export const show = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/deals/{deal}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
show.url = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: args.deal,
                }

    return show.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
show.get = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
show.head = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
    const showForm = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
        showForm.get = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DealController::show
 * @see app/Http/Controllers/DealController.php:0
 * @route '/deals/{deal}'
 */
        showForm.head = (args: { deal: string | number } | [deal: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
export const update = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/deals/{deal}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
update.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return update.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
update.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
update.patch = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
    const updateForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
        updateForm.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\DealController::update
 * @see app/Http/Controllers/DealController.php:94
 * @route '/deals/{deal}'
 */
        updateForm.patch = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:102
 * @route '/deals/{deal}'
 */
export const destroy = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/deals/{deal}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:102
 * @route '/deals/{deal}'
 */
destroy.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return destroy.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:102
 * @route '/deals/{deal}'
 */
destroy.delete = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:102
 * @route '/deals/{deal}'
 */
    const destroyForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DealController::destroy
 * @see app/Http/Controllers/DealController.php:102
 * @route '/deals/{deal}'
 */
        destroyForm.delete = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const deals = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
show: Object.assign(show, show),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default deals