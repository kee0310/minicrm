import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/commissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CommissionController::index
 * @see app/Http/Controllers/CommissionController.php:15
 * @route '/commissions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CommissionController::update
 * @see app/Http/Controllers/CommissionController.php:67
 * @route '/commissions/{commission}'
 */
export const update = (args: { commission: number | { id: number } } | [commission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/commissions/{commission}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CommissionController::update
 * @see app/Http/Controllers/CommissionController.php:67
 * @route '/commissions/{commission}'
 */
update.url = (args: { commission: number | { id: number } } | [commission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { commission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { commission: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    commission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        commission: typeof args.commission === 'object'
                ? args.commission.id
                : args.commission,
                }

    return update.definition.url
            .replace('{commission}', parsedArgs.commission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CommissionController::update
 * @see app/Http/Controllers/CommissionController.php:67
 * @route '/commissions/{commission}'
 */
update.put = (args: { commission: number | { id: number } } | [commission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CommissionController::update
 * @see app/Http/Controllers/CommissionController.php:67
 * @route '/commissions/{commission}'
 */
    const updateForm = (args: { commission: number | { id: number } } | [commission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CommissionController::update
 * @see app/Http/Controllers/CommissionController.php:67
 * @route '/commissions/{commission}'
 */
        updateForm.put = (args: { commission: number | { id: number } } | [commission: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const CommissionController = { index, update }

export default CommissionController