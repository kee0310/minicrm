import ClientController from './ClientController'
import CommissionController from './CommissionController'
import DashboardChartController from './DashboardChartController'
import DashboardController from './DashboardController'
import DealController from './DealController'
import LeadController from './LeadController'
import LegalController from './LegalController'
import LoanController from './LoanController'
import Settings from './Settings'
import UserController from './UserController'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
DashboardChartController: Object.assign(DashboardChartController, DashboardChartController),
UserController: Object.assign(UserController, UserController),
LeadController: Object.assign(LeadController, LeadController),
DealController: Object.assign(DealController, DealController),
ClientController: Object.assign(ClientController, ClientController),
CommissionController: Object.assign(CommissionController, CommissionController),
LegalController: Object.assign(LegalController, LegalController),
LoanController: Object.assign(LoanController, LoanController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers