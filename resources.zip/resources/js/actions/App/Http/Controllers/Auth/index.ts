import AuthenticatedSessionController from './AuthenticatedSessionController'
import ConfirmablePasswordController from './ConfirmablePasswordController'
import EmailVerificationNotificationController from './EmailVerificationNotificationController'
import EmailVerificationPromptController from './EmailVerificationPromptController'
import NewPasswordController from './NewPasswordController'
import PasswordController from './PasswordController'
import PasswordResetLinkController from './PasswordResetLinkController'
import RegisteredUserController from './RegisteredUserController'
import VerifyEmailController from './VerifyEmailController'
const Auth = {
    AuthenticatedSessionController: Object.assign(AuthenticatedSessionController, AuthenticatedSessionController),
PasswordResetLinkController: Object.assign(PasswordResetLinkController, PasswordResetLinkController),
NewPasswordController: Object.assign(NewPasswordController, NewPasswordController),
RegisteredUserController: Object.assign(RegisteredUserController, RegisteredUserController),
EmailVerificationNotificationController: Object.assign(EmailVerificationNotificationController, EmailVerificationNotificationController),
EmailVerificationPromptController: Object.assign(EmailVerificationPromptController, EmailVerificationPromptController),
VerifyEmailController: Object.assign(VerifyEmailController, VerifyEmailController),
ConfirmablePasswordController: Object.assign(ConfirmablePasswordController, ConfirmablePasswordController),
PasswordController: Object.assign(PasswordController, PasswordController),
}

export default Auth