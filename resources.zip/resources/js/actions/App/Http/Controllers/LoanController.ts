import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
export const notifications = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: notifications.url(options),
    method: 'get',
})

notifications.definition = {
    methods: ["get","head"],
    url: '/loans/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
notifications.url = (options?: RouteQueryOptions) => {
    return notifications.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
notifications.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: notifications.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
notifications.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: notifications.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
    const notificationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: notifications.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
        notificationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: notifications.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::notifications
 * @see app/Http/Controllers/LoanController.php:98
 * @route '/loans/notifications'
 */
        notificationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: notifications.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    notifications.form = notificationsForm
/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
export const borrowerProfile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: borrowerProfile.url(options),
    method: 'get',
})

borrowerProfile.definition = {
    methods: ["get","head"],
    url: '/loans/borrower-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
borrowerProfile.url = (options?: RouteQueryOptions) => {
    return borrowerProfile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
borrowerProfile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: borrowerProfile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
borrowerProfile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: borrowerProfile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
    const borrowerProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: borrowerProfile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
        borrowerProfileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: borrowerProfile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::borrowerProfile
 * @see app/Http/Controllers/LoanController.php:36
 * @route '/loans/borrower-profile'
 */
        borrowerProfileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: borrowerProfile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    borrowerProfile.form = borrowerProfileForm
/**
* @see \App\Http\Controllers\LoanController::updateBorrowerProfile
 * @see app/Http/Controllers/LoanController.php:132
 * @route '/loans/borrower-profile/{deal}'
 */
export const updateBorrowerProfile = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBorrowerProfile.url(args, options),
    method: 'put',
})

updateBorrowerProfile.definition = {
    methods: ["put"],
    url: '/loans/borrower-profile/{deal}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::updateBorrowerProfile
 * @see app/Http/Controllers/LoanController.php:132
 * @route '/loans/borrower-profile/{deal}'
 */
updateBorrowerProfile.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return updateBorrowerProfile.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::updateBorrowerProfile
 * @see app/Http/Controllers/LoanController.php:132
 * @route '/loans/borrower-profile/{deal}'
 */
updateBorrowerProfile.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBorrowerProfile.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LoanController::updateBorrowerProfile
 * @see app/Http/Controllers/LoanController.php:132
 * @route '/loans/borrower-profile/{deal}'
 */
    const updateBorrowerProfileForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateBorrowerProfile.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::updateBorrowerProfile
 * @see app/Http/Controllers/LoanController.php:132
 * @route '/loans/borrower-profile/{deal}'
 */
        updateBorrowerProfileForm.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateBorrowerProfile.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateBorrowerProfile.form = updateBorrowerProfileForm
/**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
export const loanDetail = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loanDetail.url(args, options),
    method: 'get',
})

loanDetail.definition = {
    methods: ["get","head"],
    url: '/loans/detail/{deal}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
loanDetail.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return loanDetail.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
loanDetail.get = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loanDetail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
loanDetail.head = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loanDetail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
    const loanDetailForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: loanDetail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
        loanDetailForm.get = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: loanDetail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::loanDetail
 * @see app/Http/Controllers/LoanController.php:108
 * @route '/loans/detail/{deal}'
 */
        loanDetailForm.head = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: loanDetail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    loanDetail.form = loanDetailForm
/**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
export const loanDetailByLoanId = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loanDetailByLoanId.url(args, options),
    method: 'get',
})

loanDetailByLoanId.definition = {
    methods: ["get","head"],
    url: '/loans/detail/by-loan/{loanId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
loanDetailByLoanId.url = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { loanId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    loanId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        loanId: args.loanId,
                }

    return loanDetailByLoanId.definition.url
            .replace('{loanId}', parsedArgs.loanId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
loanDetailByLoanId.get = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: loanDetailByLoanId.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
loanDetailByLoanId.head = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: loanDetailByLoanId.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
    const loanDetailByLoanIdForm = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: loanDetailByLoanId.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
        loanDetailByLoanIdForm.get = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: loanDetailByLoanId.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::loanDetailByLoanId
 * @see app/Http/Controllers/LoanController.php:119
 * @route '/loans/detail/by-loan/{loanId}'
 */
        loanDetailByLoanIdForm.head = (args: { loanId: string | number } | [loanId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: loanDetailByLoanId.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    loanDetailByLoanId.form = loanDetailByLoanIdForm
/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
export const preQualification = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preQualification.url(options),
    method: 'get',
})

preQualification.definition = {
    methods: ["get","head"],
    url: '/loans/pre-qualification',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
preQualification.url = (options?: RouteQueryOptions) => {
    return preQualification.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
preQualification.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preQualification.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
preQualification.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preQualification.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
    const preQualificationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preQualification.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
        preQualificationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preQualification.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::preQualification
 * @see app/Http/Controllers/LoanController.php:165
 * @route '/loans/pre-qualification'
 */
        preQualificationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preQualification.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preQualification.form = preQualificationForm
/**
* @see \App\Http\Controllers\LoanController::updatePreQualification
 * @see app/Http/Controllers/LoanController.php:241
 * @route '/loans/pre-qualification/{deal}'
 */
export const updatePreQualification = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePreQualification.url(args, options),
    method: 'put',
})

updatePreQualification.definition = {
    methods: ["put"],
    url: '/loans/pre-qualification/{deal}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::updatePreQualification
 * @see app/Http/Controllers/LoanController.php:241
 * @route '/loans/pre-qualification/{deal}'
 */
updatePreQualification.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return updatePreQualification.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::updatePreQualification
 * @see app/Http/Controllers/LoanController.php:241
 * @route '/loans/pre-qualification/{deal}'
 */
updatePreQualification.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePreQualification.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LoanController::updatePreQualification
 * @see app/Http/Controllers/LoanController.php:241
 * @route '/loans/pre-qualification/{deal}'
 */
    const updatePreQualificationForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePreQualification.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::updatePreQualification
 * @see app/Http/Controllers/LoanController.php:241
 * @route '/loans/pre-qualification/{deal}'
 */
        updatePreQualificationForm.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePreQualification.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePreQualification.form = updatePreQualificationForm
/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
export const bankSubmissionTracking = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankSubmissionTracking.url(options),
    method: 'get',
})

bankSubmissionTracking.definition = {
    methods: ["get","head"],
    url: '/loans/bank-submission-tracking',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
bankSubmissionTracking.url = (options?: RouteQueryOptions) => {
    return bankSubmissionTracking.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
bankSubmissionTracking.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: bankSubmissionTracking.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
bankSubmissionTracking.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: bankSubmissionTracking.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
    const bankSubmissionTrackingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: bankSubmissionTracking.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
        bankSubmissionTrackingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankSubmissionTracking.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::bankSubmissionTracking
 * @see app/Http/Controllers/LoanController.php:266
 * @route '/loans/bank-submission-tracking'
 */
        bankSubmissionTrackingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: bankSubmissionTracking.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    bankSubmissionTracking.form = bankSubmissionTrackingForm
/**
* @see \App\Http\Controllers\LoanController::storeBankSubmission
 * @see app/Http/Controllers/LoanController.php:364
 * @route '/loans/bank-submission-tracking'
 */
export const storeBankSubmission = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBankSubmission.url(options),
    method: 'post',
})

storeBankSubmission.definition = {
    methods: ["post"],
    url: '/loans/bank-submission-tracking',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoanController::storeBankSubmission
 * @see app/Http/Controllers/LoanController.php:364
 * @route '/loans/bank-submission-tracking'
 */
storeBankSubmission.url = (options?: RouteQueryOptions) => {
    return storeBankSubmission.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::storeBankSubmission
 * @see app/Http/Controllers/LoanController.php:364
 * @route '/loans/bank-submission-tracking'
 */
storeBankSubmission.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBankSubmission.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LoanController::storeBankSubmission
 * @see app/Http/Controllers/LoanController.php:364
 * @route '/loans/bank-submission-tracking'
 */
    const storeBankSubmissionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBankSubmission.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::storeBankSubmission
 * @see app/Http/Controllers/LoanController.php:364
 * @route '/loans/bank-submission-tracking'
 */
        storeBankSubmissionForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBankSubmission.url(options),
            method: 'post',
        })
    
    storeBankSubmission.form = storeBankSubmissionForm
/**
* @see \App\Http\Controllers\LoanController::updateBankSubmission
 * @see app/Http/Controllers/LoanController.php:403
 * @route '/loans/bank-submission-tracking/submissions/{submission}'
 */
export const updateBankSubmission = (args: { submission: string | { loan_id: string } } | [submission: string | { loan_id: string } ] | string | { loan_id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBankSubmission.url(args, options),
    method: 'put',
})

updateBankSubmission.definition = {
    methods: ["put"],
    url: '/loans/bank-submission-tracking/submissions/{submission}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::updateBankSubmission
 * @see app/Http/Controllers/LoanController.php:403
 * @route '/loans/bank-submission-tracking/submissions/{submission}'
 */
updateBankSubmission.url = (args: { submission: string | { loan_id: string } } | [submission: string | { loan_id: string } ] | string | { loan_id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'loan_id' in args) {
            args = { submission: args.loan_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.loan_id
                : args.submission,
                }

    return updateBankSubmission.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::updateBankSubmission
 * @see app/Http/Controllers/LoanController.php:403
 * @route '/loans/bank-submission-tracking/submissions/{submission}'
 */
updateBankSubmission.put = (args: { submission: string | { loan_id: string } } | [submission: string | { loan_id: string } ] | string | { loan_id: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBankSubmission.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LoanController::updateBankSubmission
 * @see app/Http/Controllers/LoanController.php:403
 * @route '/loans/bank-submission-tracking/submissions/{submission}'
 */
    const updateBankSubmissionForm = (args: { submission: string | { loan_id: string } } | [submission: string | { loan_id: string } ] | string | { loan_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateBankSubmission.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::updateBankSubmission
 * @see app/Http/Controllers/LoanController.php:403
 * @route '/loans/bank-submission-tracking/submissions/{submission}'
 */
        updateBankSubmissionForm.put = (args: { submission: string | { loan_id: string } } | [submission: string | { loan_id: string } ] | string | { loan_id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateBankSubmission.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateBankSubmission.form = updateBankSubmissionForm
/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
export const approvalAnalysis = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvalAnalysis.url(options),
    method: 'get',
})

approvalAnalysis.definition = {
    methods: ["get","head"],
    url: '/loans/approval-analysis',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
approvalAnalysis.url = (options?: RouteQueryOptions) => {
    return approvalAnalysis.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
approvalAnalysis.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approvalAnalysis.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
approvalAnalysis.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: approvalAnalysis.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
    const approvalAnalysisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: approvalAnalysis.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
        approvalAnalysisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: approvalAnalysis.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::approvalAnalysis
 * @see app/Http/Controllers/LoanController.php:436
 * @route '/loans/approval-analysis'
 */
        approvalAnalysisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: approvalAnalysis.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    approvalAnalysis.form = approvalAnalysisForm
/**
* @see \App\Http\Controllers\LoanController::storeApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
export const storeApprovalAnalysis = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeApprovalAnalysis.url(args, options),
    method: 'post',
})

storeApprovalAnalysis.definition = {
    methods: ["post"],
    url: '/loans/approval-analysis/{deal}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LoanController::storeApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
storeApprovalAnalysis.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return storeApprovalAnalysis.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::storeApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
storeApprovalAnalysis.post = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeApprovalAnalysis.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LoanController::storeApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
    const storeApprovalAnalysisForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeApprovalAnalysis.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::storeApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:500
 * @route '/loans/approval-analysis/{deal}'
 */
        storeApprovalAnalysisForm.post = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeApprovalAnalysis.url(args, options),
            method: 'post',
        })
    
    storeApprovalAnalysis.form = storeApprovalAnalysisForm
/**
* @see \App\Http\Controllers\LoanController::updateApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
export const updateApprovalAnalysis = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateApprovalAnalysis.url(args, options),
    method: 'put',
})

updateApprovalAnalysis.definition = {
    methods: ["put"],
    url: '/loans/approval-analysis/{deal}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::updateApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
updateApprovalAnalysis.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return updateApprovalAnalysis.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::updateApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
updateApprovalAnalysis.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateApprovalAnalysis.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LoanController::updateApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
    const updateApprovalAnalysisForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateApprovalAnalysis.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::updateApprovalAnalysis
 * @see app/Http/Controllers/LoanController.php:515
 * @route '/loans/approval-analysis/{deal}'
 */
        updateApprovalAnalysisForm.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateApprovalAnalysis.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateApprovalAnalysis.form = updateApprovalAnalysisForm
/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
export const disbursement = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: disbursement.url(options),
    method: 'get',
})

disbursement.definition = {
    methods: ["get","head"],
    url: '/loans/disbursement',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
disbursement.url = (options?: RouteQueryOptions) => {
    return disbursement.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
disbursement.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: disbursement.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
disbursement.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: disbursement.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
    const disbursementForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: disbursement.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
        disbursementForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: disbursement.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LoanController::disbursement
 * @see app/Http/Controllers/LoanController.php:530
 * @route '/loans/disbursement'
 */
        disbursementForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: disbursement.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    disbursement.form = disbursementForm
/**
* @see \App\Http\Controllers\LoanController::updateDisbursement
 * @see app/Http/Controllers/LoanController.php:580
 * @route '/loans/disbursement/{deal}'
 */
export const updateDisbursement = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateDisbursement.url(args, options),
    method: 'put',
})

updateDisbursement.definition = {
    methods: ["put"],
    url: '/loans/disbursement/{deal}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\LoanController::updateDisbursement
 * @see app/Http/Controllers/LoanController.php:580
 * @route '/loans/disbursement/{deal}'
 */
updateDisbursement.url = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { deal: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { deal: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    deal: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        deal: typeof args.deal === 'object'
                ? args.deal.id
                : args.deal,
                }

    return updateDisbursement.definition.url
            .replace('{deal}', parsedArgs.deal.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LoanController::updateDisbursement
 * @see app/Http/Controllers/LoanController.php:580
 * @route '/loans/disbursement/{deal}'
 */
updateDisbursement.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateDisbursement.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\LoanController::updateDisbursement
 * @see app/Http/Controllers/LoanController.php:580
 * @route '/loans/disbursement/{deal}'
 */
    const updateDisbursementForm = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDisbursement.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LoanController::updateDisbursement
 * @see app/Http/Controllers/LoanController.php:580
 * @route '/loans/disbursement/{deal}'
 */
        updateDisbursementForm.put = (args: { deal: number | { id: number } } | [deal: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDisbursement.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDisbursement.form = updateDisbursementForm
const LoanController = { notifications, borrowerProfile, updateBorrowerProfile, loanDetail, loanDetailByLoanId, preQualification, updatePreQualification, bankSubmissionTracking, storeBankSubmission, updateBankSubmission, approvalAnalysis, storeApprovalAnalysis, updateApprovalAnalysis, disbursement, updateDisbursement }

export default LoanController