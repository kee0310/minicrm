import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
const DashboardChartController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardChartController.url(options),
    method: 'get',
})

DashboardChartController.definition = {
    methods: ["get","head"],
    url: '/dashboard/charts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
DashboardChartController.url = (options?: RouteQueryOptions) => {
    return DashboardChartController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
DashboardChartController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: DashboardChartController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
DashboardChartController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: DashboardChartController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
    const DashboardChartControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: DashboardChartController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
        DashboardChartControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardChartController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardChartController::__invoke
 * @see app/Http/Controllers/DashboardChartController.php:19
 * @route '/dashboard/charts'
 */
        DashboardChartControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: DashboardChartController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    DashboardChartController.form = DashboardChartControllerForm
/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
export const pipelineDetails = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pipelineDetails.url(options),
    method: 'get',
})

pipelineDetails.definition = {
    methods: ["get","head"],
    url: '/dashboard/pipeline-details',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
pipelineDetails.url = (options?: RouteQueryOptions) => {
    return pipelineDetails.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
pipelineDetails.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pipelineDetails.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
pipelineDetails.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pipelineDetails.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
    const pipelineDetailsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pipelineDetails.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
        pipelineDetailsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pipelineDetails.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DashboardChartController::pipelineDetails
 * @see app/Http/Controllers/DashboardChartController.php:51
 * @route '/dashboard/pipeline-details'
 */
        pipelineDetailsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pipelineDetails.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pipelineDetails.form = pipelineDetailsForm
DashboardChartController.pipelineDetails = pipelineDetails

export default DashboardChartController