<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RoleSeeder::class,
            UserSeeder::class,
            LeadSeeder::class,
            DealSeeder::class,
            DealPipelineSeeder::class,
            LoanPreQualificationSeeder::class,
            LoanBankSubmissionSeeder::class,
            LegalCaseSeeder::class,
            CommissionSeeder::class,
        ]);
    }
}
