<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('deals', function (Blueprint $table) {
            $table->id();
            // human readable code, filled later
            $table->string('deal_id')->unique()->nullable();

            $table->foreignId('lead_id')->constrained('leads')->cascadeOnDelete();
            $table->string('project_name');
            $table->string('developer')->nullable();
            $table->string('unit_number')->nullable();
            $table->decimal('selling_price', 15, 2);
            $table->decimal('commission_percentage', 5, 2);
            $table->decimal('commission_amount', 15, 2)->nullable();
            $table->foreignId('salesperson_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('leader_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('loan_officer_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('legal_officer_id')->nullable()->constrained('users')->nullOnDelete();
            $table->decimal('booking_fee', 15, 2)->nullable();
            $table->date('deal_closing_date')->nullable();
            $table->string('pipeline')->default('Lead');

            $table->timestamps();

            // indexes for large scale
            $table->index(['lead_id']);
            $table->index(['salesperson_id']);
            $table->index(['leader_id']);
            $table->index(['loan_officer_id']);
            $table->index(['legal_officer_id']);
            $table->index(['pipeline']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('deals');
    }
};
