<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Client Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <a href="<?php echo e(url()->previous()); ?>"
            class="ml-4 inline-flex items-center gap-2 border border-slate-300 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.08em] text-slate-700 shadow-sm transition hover:bg-blue-500 hover:text-white">
            <span aria-hidden="true">&larr;</span>
            Back
        </a>

        <div class="grid grid-cols-3 gap-3" x-data="loanPageState()">
            <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'crm-card-body grid-cols-1 h-min']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'crm-card-body grid-cols-1 h-min']); ?>
                <div class="grid items-center justify-between gap-2">
                    <p class="text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">Client</p>
                    <h3 class="mt-1 text-2xl font-semibold text-slate-900"><?php echo e($client->name ?? '-'); ?></h3>
                </div>

                <div class="grid gap-2 mt-8 text-sm text-slate-700">
                    <div><span class="font-semibold">Lead ID:</span>
                        <?php echo e($client->id ?? '-'); ?></div>
                    <div><span class="font-semibold">Email:</span>
                        <?php echo e($client->email ?? '-'); ?></div>
                    <div><span class="font-semibold">Phone:</span>
                        <?php echo e($client->phone ?? '-'); ?></div>
                    <div><span class="font-semibold">Age:</span>
                        <?php echo e($client->age ?? '-'); ?></div>
                    <div><span class="font-semibold">IC/Passport:</span>
                        <?php echo e($client->ic_passport ?? '-'); ?></div>
                    <div><span class="font-semibold">Occupation:</span>
                        <?php echo e($client->occupation ?? '-'); ?></div>
                    <div><span class="font-semibold">Company:</span>
                        <?php echo e($client->company ?? '-'); ?></div>
                    <div><span class="font-semibold">Working Years:</span>
                        <?php echo e($client->working_years ?? '-'); ?></div>
                    <div><span class="font-semibold">Monthly Income:</span>
                        <?php echo e($client->monthly_income ? 'RM ' . number_format($client->monthly_income, 2) : '-'); ?></div>
                    <div><span class="font-semibold">Fixed Income:</span>
                        <?php echo e($client->fixed_income ? 'RM ' . number_format($client->fixed_income, 2) : '-'); ?></div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'crm-card-body col-span-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'crm-card-body col-span-2']); ?>
                <div class="mb-4 flex items-center justify-between">
                    <h3 class="text-lg font-semibold text-slate-900">Deals</h3>
                    <span class="text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">
                        <?php echo e($deals->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('Record', $deals->count())); ?>

                    </span>
                </div>

                <?php if($deals->count()): ?>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                                <div class="flex flex-wrap items-start justify-between gap-3">
                                    <div>
                                        <p class="text-xs font-semibold uppercase tracking-[0.08em] text-slate-500">
                                            <?php echo e($deal->deal_id); ?></p>
                                        <p class="text-base font-semibold text-slate-900"><?php echo e($deal->project_name); ?></p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <span
                                            class="<?php echo e($deal->pipeline->badge()); ?>"><?php echo e($deal->pipeline->value); ?></span>
                                        <button type="button" class="crm-btn-secondary text-xs text-blue-600"
                                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'client.deal.detail')">
                                            Details
                                        </button>
                                    </div>
                                </div>

                                <div class="mt-4 grid grid-cols-1 gap-4 text-sm text-slate-700 lg:grid-cols-2">
                                    <div class="space-y-2">
                                        <p><span class="font-semibold">Developer:</span>
                                            <?php echo e($deal->developer ?? '-'); ?></p>
                                        <p><span class="font-semibold">Unit Number:</span>
                                            <?php echo e($deal->unit_number ?? '-'); ?></p>
                                        <p><span class="font-semibold">Selling Price:</span> RM
                                            <?php echo e(number_format($deal->selling_price, 2)); ?></p>
                                        <p><span class="font-semibold">Created:</span>
                                            <?php echo e(optional($deal->created_at)->format('Y-m-d') ?? '-'); ?></p>
                                    </div>
                                    <div class="space-y-2">
                                        <p><span class="font-semibold">Salesperson:</span>
                                            <?php echo e($deal->salesperson?->name ?? '-'); ?></p>
                                        <p><span class="font-semibold">Leader:</span>
                                            <?php echo e($deal->leader?->name ?? '-'); ?></p>
                                        <p><span class="font-semibold">Loan Officer:</span>
                                            <?php echo e($deal->loanOfficer?->name ?? '-'); ?></p>
                                        <p><span class="font-semibold">Legal Officer:</span>
                                            <?php echo e($deal->legalOfficer?->name ?? '-'); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="crm-table-empty-inline">No deals found for this client.</div>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

            <?php echo $__env->make('deals.partials.deal-detail-modal', ['modalKey' => 'client.deal.detail'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\clients\show.blade.php ENDPATH**/ ?>