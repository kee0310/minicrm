<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section <?php echo e($attributes->merge(['class' => 'crm-card'])); ?>>
    <?php if(isset($header) && trim((string) $header) !== ''): ?>
        <header class="border-b border-slate-200 px-6 py-4">
            <?php echo e($header); ?>

        </header>
    <?php elseif($title): ?>
        <header class="border-b border-slate-200 px-6 py-4">
            <h3><?php echo e($title); ?></h3>
        </header>
    <?php endif; ?>
    <div class="crm-card-body">
        <?php echo e($slot); ?>

    </div>
</section>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\dashboard\chart-card.blade.php ENDPATH**/ ?>