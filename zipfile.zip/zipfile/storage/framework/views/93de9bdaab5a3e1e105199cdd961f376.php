<?php if(isset($users) && $users->count()): ?>
    <div class="crm-table-wrap">
        <table class="crm-table" data-sortable-table="true">
            <thead>
                <tr>
                    <th></th>
                    <th data-sort-index="1"><span class="crm-sort-btn">Name <span data-sort-indicator></span></span></th>
                    <th data-sort-index="2"><span class="crm-sort-btn">Email <span data-sort-indicator></span></span></th>
                    <th data-sort-index="3"><span class="crm-sort-btn">Role <span data-sort-indicator></span></span></th>
                    <th data-sort-index="4"><span class="crm-sort-btn">Leader <span data-sort-indicator></span></span></th>
                    <th data-sort-index="5" data-sort-type="date"><span class="crm-sort-btn">Created
                            <span data-sort-indicator></span></span></th>
                    <th></th>
                </tr>
            </thead>
            <tbody class="whitespace-nowrap">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php
                                $roleNames = $user->roles->pluck('name')->values();
                                $userPayload = [
                                    'id' => $user->id,
                                    'name' => $user->name,
                                    'email' => $user->email,
                                    'role' => $roleNames->first(),
                                    'leader_id' => $user->leader_id,
                                ];
                            ?>
                            <button type="button" class="crm-action-btn" data-user='<?php echo json_encode($userPayload, 15, 512) ?>'
                                @click="editUser = JSON.parse($el.dataset.user); editOpen = true">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </button>
                        </td>
                        <td data-sort-value="<?php echo e(strtolower((string) $user->name)); ?>" class="text-gray-900">
                            <?php echo e($user->name); ?></td>
                        <td data-sort-value="<?php echo e(strtolower((string) $user->email)); ?>"><?php echo e($user->email); ?></td>
                        <td data-sort-value="<?php echo e(strtolower((string) $roleNames->join(', '))); ?>">
                            <?php echo e($roleNames->join(', ')); ?></td>
                        <td data-sort-value="<?php echo e(strtolower((string) ($user->leader_name ?? ''))); ?>">
                            <?php echo e($user->leader_name ?? '-'); ?></td>
                        <td data-sort-value="<?php echo e(optional($user->created_at)->format('Y-m-d')); ?>" class="crm-table-date">
                            <?php echo e(optional($user->created_at)->format('Y-m-d')); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" class="inline"
                                data-confirm="Confirm to delete user <?php echo e($user->name); ?>?">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="crm-action-btn-danger">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($users->onEachSide(1)->links()); ?>

    </div>
<?php else: ?>
    <div class="crm-table-empty-inline"><?php echo e(__('No users found.')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\users\partials\users-table.blade.php ENDPATH**/ ?>