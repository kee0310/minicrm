<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'subtitle' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'subtitle' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section <?php echo e($attributes->merge(['class' => 'crm-card'])); ?>>
    <?php if($title || $subtitle): ?>
        <header class="border-b border-slate-200  px-6 py-4 ">
            <?php if($title): ?>
                <h3><?php echo e($title); ?></h3>
            <?php endif; ?>
            <?php if($subtitle): ?>
                <p class="mt-1 text-sm text-slate-500"><?php echo e($subtitle); ?></p>
            <?php endif; ?>
        </header>
    <?php endif; ?>
    <div class="crm-card-body">
        <?php echo e($slot); ?>

    </div>
</section>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\card.blade.php ENDPATH**/ ?>