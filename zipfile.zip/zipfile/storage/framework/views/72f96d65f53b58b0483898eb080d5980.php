<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'show' => false,
    'maxWidth' => '2xl',
    'simple' => false,
    'lockScroll' => true,
    'centered' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'show' => false,
    'maxWidth' => '2xl',
    'simple' => false,
    'lockScroll' => true,
    'centered' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
$maxWidth = [
    'sm' => 'sm:max-w-sm',
    'md' => 'sm:max-w-md',
    'lg' => 'sm:max-w-lg',
    'xl' => 'sm:max-w-xl',
    '2xl' => 'sm:max-w-2xl',
    '3xl' => 'sm:max-w-3xl',
    '4xl' => 'sm:max-w-4xl',
    '5xl' => 'sm:max-w-5xl',
    '6xl' => 'sm:max-w-6xl',
][$maxWidth];
?>

<div
    x-cloak
    x-data="{
        show: <?php echo \Illuminate\Support\Js::from($show)->toHtml() ?>,
        focusables() {
            // All focusable element types...
            let selector = 'a, button, input:not([type=\'hidden\']), textarea, select, details, [tabindex]:not([tabindex=\'-1\'])'
            return [...$el.querySelectorAll(selector)]
                // All non-disabled elements...
                .filter(el => ! el.hasAttribute('disabled'))
        },
        firstFocusable() { return this.focusables()[0] },
        lastFocusable() { return this.focusables().slice(-1)[0] },
        nextFocusable() { return this.focusables()[this.nextFocusableIndex()] || this.firstFocusable() },
        prevFocusable() { return this.focusables()[this.prevFocusableIndex()] || this.lastFocusable() },
        nextFocusableIndex() { return (this.focusables().indexOf(document.activeElement) + 1) % (this.focusables().length + 1) },
        prevFocusableIndex() { return Math.max(0, this.focusables().indexOf(document.activeElement)) -1 },
    }"
    x-init="$watch('show', value => {
        if (<?php echo \Illuminate\Support\Js::from($lockScroll)->toHtml() ?>) {
            if (value) {
                document.body.classList.add('overflow-y-hidden');
            } else {
                document.body.classList.remove('overflow-y-hidden');
            }
        }
        <?php echo e($attributes->has('focusable') ? 'if (value) setTimeout(() => firstFocusable().focus(), 100)' : ''); ?>

    })"
    x-on:open-modal.window="$event.detail == '<?php echo e($name); ?>' ? show = true : null"
    x-on:close-modal.window="$event.detail == '<?php echo e($name); ?>' ? show = false : null"
    x-on:close.stop="show = false"
    x-on:keydown.escape.window="show = false"
    x-on:keydown.tab.prevent="$event.shiftKey || nextFocusable().focus()"
    x-on:keydown.shift.tab.prevent="prevFocusable().focus()"
    x-show="show"
    x-bind:style="show
        ? '<?php echo e($centered ? 'display: flex !important;' : 'display: block !important;'); ?>'
        : 'display: none !important;'"
    class="fixed inset-0 z-50 overflow-y-auto px-4 py-8 sm:px-6"
    style="display: none;"
>
    <div
        x-show="show"
        class="fixed inset-0 transform transition-all"
        x-on:click="show = false"
        x-transition:enter="<?php echo e($simple ? 'ease-out duration-120' : 'ease-out duration-300'); ?>"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="<?php echo e($simple ? 'ease-in duration-100' : 'ease-in duration-200'); ?>"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
    >
        <div class="absolute inset-0 <?php echo e($simple ? 'bg-slate-900/35' : 'bg-slate-900/45 backdrop-blur-sm'); ?>"></div>
    </div>

    <div
        x-show="show"
        class="<?php echo e($centered ? 'fixed left-1/2 top-1/2 z-[60] mb-0 w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2 sm:w-full' : 'mb-6 sm:mx-auto sm:w-full'); ?> overflow-hidden rounded-xl border border-slate-200 bg-white shadow-2xl transform transition-all <?php echo e($maxWidth); ?>"
        x-transition:enter="<?php echo e($simple ? 'ease-out duration-120' : 'ease-out duration-250'); ?>"
        x-transition:enter-start="<?php echo e($simple ? 'opacity-0' : 'opacity-0 translate-y-3 sm:translate-y-0 sm:scale-95'); ?>"
        x-transition:enter-end="<?php echo e($simple ? 'opacity-100' : 'opacity-100 translate-y-0 sm:scale-100'); ?>"
        x-transition:leave="<?php echo e($simple ? 'ease-in duration-100' : 'ease-in duration-180'); ?>"
        x-transition:leave-start="<?php echo e($simple ? 'opacity-100' : 'opacity-100 translate-y-0 sm:scale-100'); ?>"
        x-transition:leave-end="<?php echo e($simple ? 'opacity-0' : 'opacity-0 translate-y-3 sm:translate-y-0 sm:scale-95'); ?>"
    >
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\modal.blade.php ENDPATH**/ ?>