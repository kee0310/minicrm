<?php
    $sortStart = $canManageLoanRecords ? 1 : 0;
    $isLegalOfficer = auth()->user()?->hasRole(\App\Enums\RoleEnum::LEGAL_OFFICER->value) ?? false;
?>
<div class="crm-table-wrap">
    <table class="crm-table crm-table-center" data-sortable-table="true">
        <thead>
            <tr>
                <?php if($canManageLoanRecords): ?>
                    <th></th>
                <?php endif; ?>
                <th data-sort-index="<?php echo e($sortStart); ?>" class="col-left"><span class="crm-sort-btn">Project <span
                            data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 1); ?>" class="col-left"><span class="crm-sort-btn">Client <span
                            data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 2); ?>"><span class="crm-sort-btn">Legal Officer <span
                            data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 3); ?>"><span class="crm-sort-btn">Lawyer Firm <span
                            data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 4); ?>" data-sort-type="date" class="whitespace-nowrap"><span
                        class="crm-sort-btn">SPA Date
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 5); ?>" data-sort-type="date"><span class="crm-sort-btn">Loan
                        Agreement Date <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 6); ?>" data-sort-type="date"><span class="crm-sort-btn">Completion
                        Date <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 7); ?>" class="w-8%"><span class="crm-sort-btn">Stamp Duty <span
                            data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 8); ?>"><span class="crm-sort-btn">Status <span
                            data-sort-indicator></span></span></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $legal = $deal->legalCase;
                    $hasLegal = !is_null($legal);
                    $legalPayload = [
                        'deal_id' => $deal->id,
                        'project_name' => $deal->project_name,
                        'client_name' => $deal->client?->name,
                        'status' => $legal?->status ?? 'Drafting',
                        'lawyer_firm' => $legal?->lawyer_firm,
                        'spa_date' => optional($legal?->spa_date)->format('Y-m-d'),
                        'loan_agreement_date' => optional($legal?->loan_agreement_date)->format('Y-m-d'),
                        'completion_date' => optional($legal?->completion_date)->format('Y-m-d'),
                        'stamp_duty' => $legal?->stamp_duty,
                        'legal_officer_id' => $deal->legal_officer_id ?? auth()->id(),
                        'has_record' => $hasLegal,
                    ];

                    $statusClass = match ($legal?->status) {
                        'Drafting' => 'bg-gray-200 text-gray-700',
                        'Pending Bank' => 'bg-blue-100 text-blue-700',
                        'Pending Customer Signature' => 'bg-amber-100 text-amber-700',
                        'Completed' => 'bg-green-100 text-green-700',
                        default => '',
                    };
                    $hideCompletedEditForLegalOfficer = $isLegalOfficer && ($legal?->status === 'Completed');
                ?>
                <tr>
                    <?php if($canManageLoanRecords): ?>
                        <td>
                            <?php if(!$hideCompletedEditForLegalOfficer): ?>
                                <button type="button" data-legal='<?php echo json_encode($legalPayload, 15, 512) ?>'
                                    @click="legalForm = JSON.parse($el.dataset.legal); openModal('loan.legal.edit')"
                                    class="crm-action-btn">
                                    <i class="fa-solid <?php echo e($hasLegal ? 'fa-pen-to-square' : 'fa-plus'); ?>"></i>
                                </button>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->deal_id ?? ''))); ?>">
                        <button type="button" class="truncate text-indigo-600 hover:underline"
                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'deal.legal.detail')">
                            <?php echo e($deal->deal_id); ?>:
                        </button><br>
                        <?php echo e($deal->project_name); ?>

                    </td>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->client?->name ?? ''))); ?>">
                        <?php echo e($deal->client?->name ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->legalOfficer?->name ?? ''))); ?>">
                        <?php echo e($deal->legalOfficer?->name ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($legal?->lawyer_firm ?? ''))); ?>">
                        <?php echo e($legal?->lawyer_firm ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(optional($legal?->spa_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date whitespace-nowrap">
                        <?php echo e(optional($legal?->spa_date)->format('Y-m-d') ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(optional($legal?->loan_agreement_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date whitespace-nowrap">
                        <?php echo e(optional($legal?->loan_agreement_date)->format('Y-m-d') ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(optional($legal?->completion_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date whitespace-nowrap">
                        <?php echo e(optional($legal?->completion_date)->format('Y-m-d') ?? '-'); ?>

                    </td>
                    <td
                        data-sort-value="<?php echo e(is_null($legal?->stamp_duty) ? '-' : ($legal->stamp_duty ? 'yes' : 'no')); ?>">
                        <?php if(is_null($legal?->stamp_duty)): ?>
                            -
                        <?php elseif($legal->stamp_duty): ?>
                            <i class="fa-solid fa-check text-green-600" aria-label="Stamp duty yes"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-xmark text-red-600" aria-label="Stamp duty no"></i>
                        <?php endif; ?>
                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) $legal?->status)); ?>">
                        <span
                            class="inline-flex text-xs items-center px-2.5 py-1 rounded-full font-semibold <?php echo e($statusClass); ?>">
                            <?php echo e($legal?->status); ?>

                        </span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($canManageLoanRecords ? '11' : '10'); ?>" class="crm-table-empty">
                        No loan approved deals found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($deals->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\legals\partials\legals-table.blade.php ENDPATH**/ ?>