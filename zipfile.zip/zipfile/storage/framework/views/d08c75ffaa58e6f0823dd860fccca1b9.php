<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Loans / Disbursement</h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div x-data="loanPageState({
                editDeal: null,
                searchTerm: <?php echo \Illuminate\Support\Js::from(request('search', ''))->toHtml() ?>,
                completionFilter: <?php echo \Illuminate\Support\Js::from(request('completion', ''))->toHtml() ?>,
                ...tableListState({
                    endpoint: '<?php echo e(route('loans.disbursement')); ?>',
                    filters: { completionFilter: 'completion' },
                }),
            })">
                <div class="crm-filter-block">
                    <?php if (isset($component)) { $__componentOriginal240eade74da28b909c777a016dde0287 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal240eade74da28b909c777a016dde0287 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-search-row','data' => ['model' => 'searchTerm','placeholder' => 'Search deal, project or client...','requestValue' => request('search', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-search-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => 'searchTerm','placeholder' => 'Search deal, project or client...','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('search', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $attributes = $__attributesOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__attributesOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $component = $__componentOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__componentOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
                    <div class="crm-filter-tabs-scroll scrollbar-hide">
                        <div class="crm-filter-tabs">
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'completionFilter','value' => '','label' => 'All','requestValue' => request('completion', ''),'all' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'completionFilter','value' => '','label' => 'All','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('completion', '')),'all' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'completionFilter','value' => \App\Enums\CompletionFilterEnum::NEW->value,'label' => 'New','requestValue' => request('completion', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'completionFilter','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\App\Enums\CompletionFilterEnum::NEW->value),'label' => 'New','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('completion', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'completionFilter','value' => \App\Enums\CompletionFilterEnum::COMPLETED->value,'label' => 'Completed','requestValue' => request('completion', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'completionFilter','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\App\Enums\CompletionFilterEnum::COMPLETED->value),'label' => 'Completed','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('completion', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

                <div id="live-table-container" @click="handleTableClick($event)"><?php echo $__env->make('loans.partials.disbursement-table', [
                    'approvedSubmissions' => $approvedSubmissions,
                    'canManageLoanRecords' => $canManageLoanRecords,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>

                
                <?php echo $__env->make('deals.partials.deal-detail-modal', ['modalKey' => 'loan.disbursement.detail'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php echo $__env->make('loans.partials.disbursement-form-modal', [
                    'canManageLoanRecords' => $canManageLoanRecords,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\disbursement.blade.php ENDPATH**/ ?>