<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'index',
    'bankOptions' => [],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'index',
    'bankOptions' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="rounded-md border border-gray-200 p-3">
    <h5 class="mb-3 text-sm font-semibold text-gray-800">Recommendation <?php echo e($index); ?></h5>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
            <label class="crm-form-label">Recommended
                Bank</label>
            <select name="recommended_bank_<?php echo e($index); ?>" x-model="editDeal.recommended_bank_<?php echo e($index); ?>"
                class="crm-form-select">
                <option value="">-</option>
                <?php $__currentLoopData = $bankOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bank); ?>"><?php echo e($bank); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="crm-form-label">Approval
                Probability (%)</label>
            <input type="number" name="approval_probability_<?php echo e($index); ?>" min="0" max="100"
                x-model="editDeal.approval_probability_<?php echo e($index); ?>" class="crm-form-input" />
        </div>
        <div>
            <label class="crm-form-label">Loan Margin
                (%)</label>
            <select name="loan_margin_<?php echo e($index); ?>" x-model="editDeal.loan_margin_<?php echo e($index); ?>"
                class="crm-form-select">
                <option value="">-</option>
                <option value="70">70%</option>
                <option value="80">80%</option>
                <option value="90">90%</option>
            </select>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\partials\pre-qualification-recommendation-fields.blade.php ENDPATH**/ ?>