<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'model' => 'searchTerm',
    'placeholder' => 'Search...',
    'requestValue' => '',
    'submitAction' => 'refreshList()',
    'clearAction' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'model' => 'searchTerm',
    'placeholder' => 'Search...',
    'requestValue' => '',
    'submitAction' => 'refreshList()',
    'clearAction' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $clearAction ??= "{$model} = ''; {$submitAction}";
    $isEmpty = trim((string) $requestValue) === '';
?>

<div class="crm-filter-search-row">
    <div class="crm-filter-search-input-wrap">
        <input type="text" x-model="<?php echo e($model); ?>" value="<?php echo e($requestValue); ?>"
            @keydown.enter.prevent="<?php echo e($submitAction); ?>" placeholder="<?php echo e($placeholder); ?>"
            class="crm-filter-search-input" />
        <button type="button" :class="<?php echo e($model); ?> ? 'opacity-100' : 'opacity-0 pointer-events-none'"
            @click="<?php echo e($clearAction); ?>"
            class="crm-filter-search-clear <?php echo e($isEmpty ? 'opacity-0 pointer-events-none' : 'opacity-100'); ?>"
            aria-label="Clear search">
            <i class="fa-solid fa-xmark"></i>
        </button>
    </div>
    <button type="button" @click="<?php echo e($submitAction); ?>" class="crm-btn-secondary crm-filter-search-submit"
        aria-label="Search">
        <i class="fa-solid fa-magnifying-glass"></i>
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\filter-search-row.blade.php ENDPATH**/ ?>