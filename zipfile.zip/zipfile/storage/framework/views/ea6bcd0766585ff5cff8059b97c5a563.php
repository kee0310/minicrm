<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'crm-btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\primary-button.blade.php ENDPATH**/ ?>