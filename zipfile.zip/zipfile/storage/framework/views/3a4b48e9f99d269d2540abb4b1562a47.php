<?php
    $sortStart = $canManageLoanRecords ? 1 : 0;
?>
<div class="crm-table-wrap">
    <table class="crm-table crm-table-center" data-sortable-table="true">
        <thead>
            <tr>
                <?php if($canManageLoanRecords): ?>
                    <th></th>
                <?php endif; ?>
                <th data-sort-index="<?php echo e($sortStart); ?>"><span class="crm-sort-btn">Project
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 1); ?>"><span class="crm-sort-btn">Client
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 2); ?>"><span class="crm-sort-btn">Loan Officer
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 3); ?>"><span class="crm-sort-btn">Risk
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 4); ?>" class="w-[15%]">
                    <span class="crm-sort-btn whitespace-nowrap">Bank 1
                        <span data-sort-indicator></span></span>
                </th>
                <th data-sort-index="<?php echo e($sortStart + 5); ?>" class="w-[15%]">
                    <span class="crm-sort-btn whitespace-nowrap">Bank 2
                        <span data-sort-indicator></span></span>
                </th>
                <th data-sort-index="<?php echo e($sortStart + 6); ?>" class="w-[15%]">
                    <span class="crm-sort-btn whitespace-nowrap">Bank 3
                        <span data-sort-indicator></span></span>
                </th>
                <th data-sort-index="<?php echo e($sortStart + 7); ?>" data-sort-type="date"><span
                        class="crm-sort-btn whitespace-nowrap">Qualificated
                        at <span data-sort-indicator></span></span></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $pre = $deal->preQualification;
                    $riskGrade = $pre?->riskGrade() ?? $pre?->risk_grade;
                    $riskClass =
                        $riskGrade === 'C'
                            ? 'bg-red-100 text-red-700'
                            : ($riskGrade === 'B'
                                ? 'bg-amber-100 text-amber-700'
                                : ($riskGrade === 'A'
                                    ? 'bg-green-100 text-green-700'
                                    : ''));
                    $storedRecommendations = is_array($pre?->recommended_banks) ? $pre->recommended_banks : [];
                    $hasStructuredRecommendations =
                        !empty($storedRecommendations) &&
                        is_array($storedRecommendations[0] ?? null) &&
                        array_key_exists('bank', $storedRecommendations[0]);

                    if ($hasStructuredRecommendations) {
                        $recommendations = collect([0, 1, 2])
                            ->map(
                                fn($index) => [
                                    'bank' => $storedRecommendations[$index]['bank'] ?? null,
                                    'approval_probability' =>
                                        $storedRecommendations[$index]['approval_probability'] ?? null,
                                    'loan_margin' => $storedRecommendations[$index]['loan_margin'] ?? null,
                                ],
                            )
                            ->all();
                    } else {
                        $recommendations = collect([0, 1, 2])
                            ->map(
                                fn($index) => [
                                    'bank' => $storedRecommendations[$index] ?? null,
                                    'approval_probability' => null,
                                    'loan_margin' => null,
                                ],
                            )
                            ->all();
                    }
                    $hasPreQualificationData =
                        !is_null($pre?->pre_qualification_date) ||
                        collect($recommendations)->contains(function ($item) {
                            return !empty($item['bank']) ||
                                !is_null($item['approval_probability']) ||
                                !is_null($item['loan_margin']);
                        });
                    $prePayload = [
                        'deal_id' => $deal->id,
                        'has_record' => $hasPreQualificationData,
                        'deal_code' => $deal->deal_id,
                        'project_name' => $deal->project_name,
                        'client_name' => $deal->client?->name,
                        'pre_qualification_date' =>
                            optional($pre?->pre_qualification_date)->format('Y-m-d') ?? now()->format('Y-m-d'),
                        'recommended_bank_1' => $recommendations[0]['bank'] ?? null,
                        'recommended_bank_2' => $recommendations[1]['bank'] ?? null,
                        'recommended_bank_3' => $recommendations[2]['bank'] ?? null,
                        'approval_probability_1' => $recommendations[0]['approval_probability'] ?? null,
                        'approval_probability_2' => $recommendations[1]['approval_probability'] ?? null,
                        'approval_probability_3' => $recommendations[2]['approval_probability'] ?? null,
                        'loan_margin_1' => $recommendations[0]['loan_margin'] ?? null,
                        'loan_margin_2' => $recommendations[1]['loan_margin'] ?? null,
                        'loan_margin_3' => $recommendations[2]['loan_margin'] ?? null,
                    ];
                ?>
                <tr>
                    <?php if($canManageLoanRecords): ?>
                        <td>
                            <button type="button" data-pre='<?php echo json_encode($prePayload, 15, 512) ?>'
                                @click="editDeal = JSON.parse($el.dataset.pre); openModal('loan.prequalification.edit')"
                                class="crm-action-btn">
                                <i class="fa-solid <?php echo e($hasPreQualificationData ? 'fa-pen-to-square' : 'fa-plus'); ?>"></i>
                            </button>
                        </td>
                    <?php endif; ?>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->deal_id ?? ''))); ?>">
                        <button type="button" class="truncate text-indigo-600 hover:underline"
                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'loan.prequalification.detail')">
                            <?php echo e($deal->deal_id); ?>:
                        </button><br>
                        <?php echo e($deal->project_name); ?>

                    </td>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->client?->name ?? ''))); ?>">
                        <?php echo e($deal->client?->name); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->loanOfficer?->name ?? ''))); ?>">
                        <?php echo e($deal->loanOfficer?->name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($riskGrade ?? ''))); ?>">
                        <span
                            class="inline-flex items-center px-2.5 py-1 rounded-full font-semibold <?php echo e($riskClass); ?>"><?php echo e($riskGrade ?? '-'); ?></span>
                    </td>
                    <?php for($i = 0; $i < 3; $i++): ?>
                        <td
                            data-sort-value="<?php echo e(strtolower((string) (($recommendations[$i]['bank'] ?? '') . ' ' . ($recommendations[$i]['loan_margin'] ?? '') . ' ' . ($recommendations[$i]['approval_probability'] ?? '')))); ?>">
                            <?php $rec = $recommendations[$i] ?? null; ?>

                            <?php if($rec): ?>
                                <div class="grid">
                                    <?php if(!empty($rec['bank'])): ?>
                                        <b><?php echo e($rec['bank']); ?></b>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                    <?php if(isset($rec['loan_margin'])): ?>
                                        <em class="text-xs">
                                            Loan Margin: <?php echo e($rec['loan_margin']); ?>%
                                        </em>
                                    <?php endif; ?>
                                    <?php if(isset($rec['approval_probability'])): ?>
                                        <em class="text-xs">
                                            Approval Probability: <?php echo e($rec['approval_probability']); ?>%
                                        </em>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </td>
                    <?php endfor; ?>
                    <td data-sort-value="<?php echo e(optional($pre?->pre_qualification_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date">
                        <?php echo e(optional($pre?->pre_qualification_date)->format('Y-m-d') ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($canManageLoanRecords ? '9' : '8'); ?>" class="crm-table-empty">
                        No new deals found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($deals->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\partials\pre-qualification-table.blade.php ENDPATH**/ ?>