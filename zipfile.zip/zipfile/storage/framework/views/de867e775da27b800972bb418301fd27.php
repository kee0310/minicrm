<?php
    $sortStart = $canManageLoanRecords ? 1 : 0;
?>
<div class="crm-table-wrap">
    <table class="crm-table crm-table-center" data-sortable-table="true">
        <thead>
            <tr>
                <?php if($canManageLoanRecords): ?>
                    <th></th>
                <?php endif; ?>
                <th data-sort-index="<?php echo e($sortStart); ?>" class="w-[15%]"><span class="crm-sort-btn">Project
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 1); ?>" class="col-left"><span class="crm-sort-btn">Client
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 2); ?>"><span class="crm-sort-btn">Loan Officer
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 3); ?>"><span class="crm-sort-btn">Risk
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 4); ?>" data-sort-type="number"><span class="crm-sort-btn">Existing
                        Loans <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 5); ?>" data-sort-type="number"><span class="crm-sort-btn">Monthly
                        Commitments <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 6); ?>" data-sort-type="number"><span class="crm-sort-btn">Credit
                        Card Limits <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 7); ?>" data-sort-type="number"><span class="crm-sort-btn">Card
                        Utilization (%) <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 8); ?>"><span class="crm-sort-btn">CCRIS
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 9); ?>"><span class="crm-sort-btn">CTOS
                        <span data-sort-indicator></span></span></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $client = $deal->client;
                    $financial = $deal->preQualification;
                    $hasFinancial = !is_null($financial);
                    $riskGrade = $financial?->riskGrade() ?? $financial?->risk_grade;
                    $riskClass =
                        $riskGrade === 'C'
                            ? 'bg-red-100 text-red-700'
                            : ($riskGrade === 'B'
                                ? 'bg-amber-100 text-amber-700'
                                : ($riskGrade === 'A'
                                    ? 'bg-green-100 text-green-700'
                                    : ''));
                    $clientPayload = [
                        'id' => $deal->id,
                        'deal_id' => $deal->deal_id,
                        'lead_id' => $deal->lead_id,
                        'name' => $client->name,
                        'email' => $client->email,
                        'phone' => $client->phone,
                        'age' => $client->age,
                        'ic_passport' => $client->ic_passport,
                        'occupation' => $client->occupation,
                        'company' => $client->company,
                        'monthly_income' => $client->monthly_income,
                        'risk_grade' => $riskGrade,
                        'existing_loans' => $financial?->existing_loans,
                        'monthly_commitments' => $financial?->monthly_commitments,
                        'credit_card_limits' => $financial?->credit_card_limits,
                        'credit_card_utilization' => $financial?->credit_card_utilization,
                        'ccris' => $financial?->ccris,
                        'ctos' => $financial?->ctos,
                        'loan_officer_id' => $deal->loan_officer_id ?? ($currentLoanOfficerId ?? auth()->id()),
                        'has_record' => $hasFinancial,
                    ];
                ?>
                <tr>
                    <?php if($canManageLoanRecords): ?>
                        <td>
                            <button type="button" data-client='<?php echo json_encode($clientPayload, 15, 512) ?>'
                                @click="editClient = JSON.parse($el.dataset.client); openModal('loan.borrower.edit')"
                                class="crm-action-btn">
                                <i class="fa-solid <?php echo e($hasFinancial ? 'fa-pen-to-square' : 'fa-plus'); ?>"></i>
                            </button>
                        </td>
                    <?php endif; ?>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->deal_id ?? ''))); ?>">
                        <button type="button" class="truncate text-indigo-600 hover:underline"
                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'loan.borrower.detail')">
                            <?php echo e($deal->deal_id); ?>:
                        </button><br>
                        <?php echo e($deal->project_name); ?>

                    </td>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->client?->name ?? ''))); ?>">
                        <?php echo e($deal->client?->name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->loan_officer_name ?? ''))); ?>">
                        <?php echo e($deal->loan_officer_name ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($riskGrade ?? ''))); ?>">
                        <span
                            class="inline-flex items-center px-2.5 py-1 rounded-full font-semibold <?php echo e($riskClass); ?>"><?php echo e($riskGrade ?? '-'); ?></span>
                    </td>
                    <td data-sort-value="<?php echo e((float) ($financial?->existing_loans ?? 0)); ?>">
                        <?php echo e($financial?->existing_loans ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e((float) ($financial?->monthly_commitments ?? 0)); ?>">
                        <?php echo e($financial?->monthly_commitments ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e((float) ($financial?->credit_card_limits ?? 0)); ?>">
                        <?php echo e($financial?->credit_card_limits ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e((float) ($financial?->credit_card_utilization ?? 0)); ?>">
                        <?php echo e($financial?->credit_card_utilization !== null ? $financial->credit_card_utilization . '%' : '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($financial?->ccris ?? ''))); ?>">
                        <?php echo e($financial?->ccris ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($financial?->ctos ?? ''))); ?>">
                        <?php echo e($financial?->ctos ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($canManageLoanRecords ? '11' : '10'); ?>" class="crm-table-empty">
                        No deals found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($deals->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\partials\borrower-profile-table.blade.php ENDPATH**/ ?>