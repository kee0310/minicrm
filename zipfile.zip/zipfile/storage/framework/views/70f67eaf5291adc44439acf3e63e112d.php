<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $headerSubtitle = $dashboardSubtitle ?? 'Executive and operational overview';
    ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between gap-3">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e($dashboardTitle ?? 'CRM Dashboard'); ?></h2>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
        $dashboardData = [
            'chartEndpoint' => $dashboardChartsEndpoint ?? null,
            'pipelineDetailsEndpoint' => $dashboardPipelineDetailsEndpoint ?? null,
            'monthLabel' => $monthNav['label'] ?? '',
            'totalLeadsMonth' => (int) ($executive['new_leads_month'] ?? 0),
            'salesPerformance' => null,
            'commissionTrend' => null,
            'leadsBySource' => [],
            'pipelineStages' => [],
        ];
    ?>
    <div id="dashboard-data" class="hidden" aria-hidden="true" data-dashboard='<?php echo json_encode($dashboardData, 15, 512) ?>'></div>

    <div class="space-y-4 crm-dashboard-scroll">
        <!-- Month Nav -->
        <div class="flex justify-end">
            <?php echo $__env->make('dashboard.partials.month-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <!-- KPIs -->
        <section class="grid grid-cols-2 gap-3 md:grid-cols-4">
            <?php echo $__env->make('dashboard.partials.kpis', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </section>

        <!-- Charts & Reports -->
        <section class="grid grid-cols-1 gap-4 md:grid-cols-3">
            <?php if (isset($component)) { $__componentOriginalc80ef515591a62acda165e9f7fcc4db2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.chart-card','data' => ['title' => 'Leads by Source','class' => 'crm-anim-pop','style' => '--crm-anim-delay: 120ms;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.chart-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Leads by Source','class' => 'crm-anim-pop','style' => '--crm-anim-delay: 120ms;']); ?>
                <div id="dashboard-leads-source"></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $attributes = $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $component = $__componentOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc80ef515591a62acda165e9f7fcc4db2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.chart-card','data' => ['title' => 'Pipeline Overview','class' => 'crm-anim-pop','style' => '--crm-anim-delay: 180ms;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.chart-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pipeline Overview','class' => 'crm-anim-pop','style' => '--crm-anim-delay: 180ms;']); ?>
                <div id="dashboard-pipeline-overview"></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $attributes = $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $component = $__componentOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc80ef515591a62acda165e9f7fcc4db2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.chart-card','data' => ['title' => 'Total Commission (Past 5 Months)','class' => 'crm-anim-pop','style' => '--crm-anim-delay: 240ms;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.chart-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Total Commission (Past 5 Months)','class' => 'crm-anim-pop','style' => '--crm-anim-delay: 240ms;']); ?>
                <div class="h-[300px] flex items-center pt-4">
                    <canvas id="dashboard-total-commission-line"></canvas>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $attributes = $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $component = $__componentOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
        </section>

        <?php if($canViewMonthlyPerformance): ?>
            <!-- Monthly Performance Bar Chart -->
            <section name="Monthly Performance" class="crm-anim-fade-up" style="--crm-anim-delay: 260ms;">
                <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
                    <?php if (isset($component)) { $__componentOriginalc80ef515591a62acda165e9f7fcc4db2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.chart-card','data' => ['class' => 'crm-dash-chart-panel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.chart-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'crm-dash-chart-panel']); ?>
                         <?php $__env->slot('header', null, []); ?> 
                            <div class="flex items-center relative h-8">
                                <!-- Left-aligned button -->
                                <a class="mr-3 rounded-lg border border-slate-300 bg-blue-500 px-3 py-2 text-[8px] font-semibold uppercase text-white shadow-sm transition hover:bg-white hover:text-slate-700"
                                    href="<?php echo e(route('dashboard.salespeople', ['tab' => 'salesperson'])); ?>">
                                    View All
                                </a>

                                <!-- Centered heading -->
                                <h3 class="absolute left-1/2 -translate-x-1/2">Salesperson</h3>
                            </div>
                         <?php $__env->endSlot(); ?>
                        <div class="h-[360px] max-w-[500px] m-auto"><canvas id="salespersonPerformanceChart"></canvas>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $attributes = $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $component = $__componentOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc80ef515591a62acda165e9f7fcc4db2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.chart-card','data' => ['title' => 'Leader','class' => 'crm-dash-chart-panel']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.chart-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Leader','class' => 'crm-dash-chart-panel']); ?>
                         <?php $__env->slot('header', null, []); ?> 
                            <div class="flex items-center relative h-8">
                                <!-- Left-aligned button -->
                                <a class="mr-3 rounded-lg border border-slate-300 bg-blue-500 px-3 py-2 text-[8px] font-semibold uppercase text-white shadow-sm transition hover:bg-white hover:text-slate-700"
                                    href="<?php echo e(route('dashboard.salespeople', ['tab' => 'leader'])); ?>">
                                    View All
                                </a>

                                <!-- Centered heading -->
                                <h3 class="absolute left-1/2 -translate-x-1/2">Leader</h3>
                            </div>
                         <?php $__env->endSlot(); ?>
                        <div class="h-[360px] max-w-[500px] m-auto"><canvas id="leaderPerformanceChart"></canvas></div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $attributes = $__attributesOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__attributesOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2)): ?>
<?php $component = $__componentOriginalc80ef515591a62acda165e9f7fcc4db2; ?>
<?php unset($__componentOriginalc80ef515591a62acda165e9f7fcc4db2); ?>
<?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <!-- Overview Dashboard -->
        <section name="Overview Dashboard">
            <?php echo $__env->make('dashboard.partials.dashboard-overview', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </section>
    </div>

    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'dashboard-pipeline-stage-modal','show' => false,'maxWidth' => '4xl','simple' => true,'lockScroll' => false,'centered' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'dashboard-pipeline-stage-modal','show' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'maxWidth' => '4xl','simple' => true,'lockScroll' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'centered' => true]); ?>
        <div class="border-b border-slate-200 px-5 py-3">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <h3 id="pipeline-stage-modal-title" class="text-base font-semibold text-slate-900">Pipeline Stage
                    </h3>
                    <p id="pipeline-stage-modal-subtitle" class="mt-0.5 text-xs text-slate-500"></p>
                </div>
                <button type="button" class="text-slate-500 hover:text-slate-700"
                    x-on:click="$dispatch('close-modal', 'dashboard-pipeline-stage-modal')">
                    <span class="sr-only">Close</span>
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
        </div>
        <div class="max-h-[70vh] overflow-y-auto mb-2">
            <div id="pipeline-stage-modal-loading" class="hidden py-8 text-center text-sm text-slate-500">
                Loading stage details...</div>
            <div id="pipeline-stage-modal-empty" class="hidden py-8 text-center text-sm text-slate-500">
                No records found for this stage.</div>
            <div id="pipeline-stage-modal-error" class="hidden py-8 text-center text-sm text-rose-600">
                Failed to load stage details.</div>
            <div id="pipeline-stage-modal-table-wrap" class="hidden overflow-x-auto px-5 py-4">
                <table class="min-w-full divide-y divide-slate-200 text-sm border border-slate-200">
                    <thead class="bg-slate-100 text-left text-xs font-semibold uppercase tracking-wide text-slate-600">
                        <tr>
                            <th class="px-3 py-2 text-center">No.</th>
                            <th class="px-3 py-2">Deal ID</th>
                            <th class="px-3 py-2">Project Name</th>
                            <th class="px-3 py-2">Salesperson</th>
                            <th class="px-3 py-2">Leader</th>
                            <th class="px-3 py-2">Created Date</th>
                            <th id="pipeline-stage-modal-stage-date-header" class="px-3 py-2">Stage Date</th>
                        </tr>
                    </thead>
                    <tbody id="pipeline-stage-modal-tbody" class="divide-y divide-slate-200 bg-white text-slate-700">
                    </tbody>
                </table>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/dashboard.js'); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\dashboard\index.blade.php ENDPATH**/ ?>