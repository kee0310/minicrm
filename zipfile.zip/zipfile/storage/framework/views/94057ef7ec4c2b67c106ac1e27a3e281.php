<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $headerSubtitle = $pageSubtitle ?? '';
    ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between gap-3">
            <div>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e($pageTitle ?? 'Salesperson Performance'); ?>

                </h2>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <a href="<?php echo e(url()->route('dashboard.index')); ?>"
        class="ml-4 inline-flex items-center gap-2 border border-slate-300 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.08em] text-slate-700 shadow-sm transition hover:bg-blue-500 hover:text-white">
        <span aria-hidden="true">&larr;</span>
        Back
    </a>

    <div class="space-y-6">
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php
                $activeTab = $activeTab ?? request('tab', 'salesperson');
                $isLeaderTab = $activeTab === 'leader';
                $listTitle = $isLeaderTab ? 'List of leaders' : 'List of salesperson';
                $emptyMessage = $isLeaderTab ? 'No leader data available.' : 'No salesperson data available.';
                $searchPlaceholder = $isLeaderTab ? 'Search leader...' : 'Search salesperson or leader...';
            ?>
            <div class="text-gray-900" x-data="{
                searchTerm: <?php echo \Illuminate\Support\Js::from(request('search', ''))->toHtml() ?>,
                monthFilter: <?php echo \Illuminate\Support\Js::from($selectedMonth ?? '')->toHtml() ?>,
                monthPickerOpen: false,
                monthPickerYear: null,
                monthPickerMonth: null,
                monthLabels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                initMonthPicker() {
                    const parts = String(this.monthFilter || '').split('-');
                    const year = Number(parts[0]) || new Date().getFullYear();
                    const month = Number(parts[1]) || (new Date().getMonth() + 1);
                    this.monthPickerYear = year;
                    this.monthPickerMonth = month;
                },
                monthPickerLabel() {
                    const label = this.monthLabels[(this.monthPickerMonth || 1) - 1] || 'Jan';
                    return `${label} ${this.monthPickerYear}`;
                },
                selectMonth(index) {
                    const monthValue = String(index + 1).padStart(2, '0');
                    this.monthPickerMonth = index + 1;
                    this.monthFilter = `${this.monthPickerYear}-${monthValue}`;
                    this.monthPickerOpen = false;
                    this.refreshList();
                },
                currentTab: <?php echo \Illuminate\Support\Js::from($activeTab)->toHtml() ?>,
                ...tableListState({
                    endpoint: '<?php echo e(route('dashboard.salespeople')); ?>',
                    filters: { currentTab: 'tab', monthFilter: 'month' },
                }),
            }" x-init="initMonthPicker()">
                <div class="flex items-center justify-between gap-3 mb-4">
                    <h3 class="text-lg font-medium"><?php echo e($listTitle); ?></h3>
                </div>

                <div class="crm-filter-block">
                    <div class="crm-filter-toolbar">
                        <?php if (isset($component)) { $__componentOriginal240eade74da28b909c777a016dde0287 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal240eade74da28b909c777a016dde0287 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-search-row','data' => ['model' => 'searchTerm','placeholder' => $searchPlaceholder,'requestValue' => request('search', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-search-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => 'searchTerm','placeholder' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($searchPlaceholder),'request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('search', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $attributes = $__attributesOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__attributesOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $component = $__componentOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__componentOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
                        <div class="crm-month-picker" @click.outside="monthPickerOpen = false">
                            <span class="crm-form-label">Month</span>
                            <button type="button" class="crm-month-picker-trigger"
                                @click="monthPickerOpen = !monthPickerOpen" :aria-expanded="monthPickerOpen">
                                <span x-text="monthPickerLabel()"></span>
                                <i class="fa-solid fa-chevron-down text-[10px] text-slate-500"></i>
                            </button>
                            <div class="crm-month-picker-panel" x-show="monthPickerOpen" x-transition.origin.top.right>
                                <div class="crm-month-picker-year">
                                    <button type="button" class="crm-month-picker-year-btn" @click="monthPickerYear -= 1"
                                        aria-label="Previous year">
                                        <i class="fa-solid fa-chevron-left"></i>
                                    </button>
                                    <span class="crm-month-picker-year-label" x-text="monthPickerYear"></span>
                                    <button type="button" class="crm-month-picker-year-btn" @click="monthPickerYear += 1"
                                        aria-label="Next year">
                                        <i class="fa-solid fa-chevron-right"></i>
                                    </button>
                                </div>
                                <div class="crm-month-picker-grid">
                                    <template x-for="(label, index) in monthLabels" :key="label">
                                        <button type="button" class="crm-month-picker-month"
                                            :class="monthPickerMonth === (index + 1) ? 'is-active' : ''"
                                            @click="selectMonth(index)" x-text="label"></button>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="crm-filter-tabs-scroll scrollbar-hide">
                        <div class="crm-filter-tabs">
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'currentTab','value' => 'salesperson','label' => 'Salesperson','requestValue' => $activeTab]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'currentTab','value' => 'salesperson','label' => 'Salesperson','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeTab)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'currentTab','value' => 'leader','label' => 'Leader','requestValue' => $activeTab]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'currentTab','value' => 'leader','label' => 'Leader','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeTab)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>


                <div class="crm-table-wrap">
                    <?php if($isLeaderTab): ?>
                        <table class="crm-table" data-sortable-table="true">
                            <thead>
                                <tr>
                                    <th class="w-[50px]"><span class="crm-sort-btn pointer-events-none">No.</span></th>
                                    <th data-sort-index="1">
                                        <span class="crm-sort-btn">Leader <span data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="2" data-sort-type="number">
                                        <span class="crm-sort-btn">Team Size <span data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="3" data-sort-type="number">
                                        <span class="crm-sort-btn">Team Converted Lead <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="4" data-sort-type="number">
                                        <span class="crm-sort-btn">Team Completed Deal <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="5" data-sort-type="number">
                                        <span class="crm-sort-btn">Team Deal Close Rate <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="6" data-sort-type="number">
                                        <span class="crm-sort-btn">Team Avg Complete Day <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="7" data-sort-type="number">
                                        <span class="crm-sort-btn">Team Total Commission <span
                                                data-sort-indicator></span></span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td data-sort-value="<?php echo e(strtolower((string) $row['leader'])); ?>">
                                            <?php echo e($row['leader']); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['team_size']); ?>">
                                            <?php echo e(number_format($row['team_size'])); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['converted_leads']); ?>">
                                            <?php echo e(number_format($row['converted_leads'])); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['completed_deals']); ?>">
                                            <?php echo e(number_format($row['completed_deals'])); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['close_rate']); ?>">
                                            <?php echo e(number_format($row['close_rate'], 2)); ?>%
                                        </td>
                                        <td data-sort-value="<?php echo e($row['avg_complete_days'] ?? ''); ?>">
                                            <?php echo e($row['avg_complete_days'] !== null ? number_format($row['avg_complete_days'], 1) : '-'); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['total_commission']); ?>">
                                            RM <?php echo e(number_format($row['total_commission'], 2)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="crm-table-empty"><?php echo e($emptyMessage); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <table class="crm-table" data-sortable-table="true">
                            <thead>
                                <tr>
                                    <th class="w-[50px]"><span class="crm-sort-btn pointer-events-none">No.</span></th>
                                    <th data-sort-index="1">
                                        <span class="crm-sort-btn">Salesperson <span data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="2">
                                        <span class="crm-sort-btn">Leader <span data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="3" data-sort-type="number">
                                        <span class="crm-sort-btn">Converted Lead <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="4" data-sort-type="number">
                                        <span class="crm-sort-btn">Completed Deal <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="5" data-sort-type="number">
                                        <span class="crm-sort-btn">Deal Close Rate <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="6" data-sort-type="number">
                                        <span class="crm-sort-btn">Avg Complete Day <span
                                                data-sort-indicator></span></span>
                                    </th>
                                    <th data-sort-index="7" data-sort-type="number">
                                        <span class="crm-sort-btn">Total Commission <span
                                                data-sort-indicator></span></span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td data-sort-value="<?php echo e(strtolower((string) $row['name'])); ?>">
                                            <?php echo e($row['name']); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e(strtolower((string) $row['leader'])); ?>">
                                            <?php echo e($row['leader']); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['converted_leads']); ?>">
                                            <?php echo e(number_format($row['converted_leads'])); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['completed_deals']); ?>">
                                            <?php echo e(number_format($row['completed_deals'])); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['close_rate']); ?>">
                                            <?php echo e(number_format($row['close_rate'], 2)); ?>%
                                        </td>
                                        <td data-sort-value="<?php echo e($row['avg_complete_days'] ?? ''); ?>">
                                            <?php echo e($row['avg_complete_days'] !== null ? number_format($row['avg_complete_days'], 1) : '-'); ?>

                                        </td>
                                        <td data-sort-value="<?php echo e($row['total_commission']); ?>">
                                            RM <?php echo e(number_format($row['total_commission'], 2)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="crm-table-empty"><?php echo e($emptyMessage); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <div class="mt-4">
                    <?php echo e($rows->onEachSide(1)->links()); ?>

                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\dashboard\salespeople.blade.php ENDPATH**/ ?>