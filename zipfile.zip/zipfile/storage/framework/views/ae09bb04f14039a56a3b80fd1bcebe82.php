<?php if($canManageLoanRecords): ?>
    <div x-show="isModalOpen('loan.prequalification.edit')" x-cloak
        x-transition:enter="transition ease-in-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in-out duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
        class="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
        @click.self="closeModal('loan.prequalification.edit')">
        <div x-transition:enter="transition ease-in-out duration-200" x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in-out duration-150"
            x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
            class="crm-modal-panel">
            <div class="crm-modal-header">
                <h4 class="crm-modal-title" x-text="editDeal?.has_record ? 'Edit Pre-Qualification' : 'Add Pre-Qualification'">
                    Edit
                    Pre-Qualification</h4>
                <button type="button" class="text-gray-500 hover:text-gray-700"
                    @click="closeModal('loan.prequalification.edit')">X</button>
            </div>

            <form method="POST" :action="'<?php echo e(url('/loans/pre-qualification')); ?>/' + (editDeal?.deal_id ?? '')" data-preserve-list-state>
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = [1, 2, 3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendationIndex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('loans.partials.pre-qualification-recommendation-fields', [
                            'index' => $recommendationIndex,
                            'bankOptions' => $bankOptions,
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div>
                        <label class="crm-form-label">Pre-Qualification Date</label>
                        <input type="date" name="pre_qualification_date" x-model="editDeal.pre_qualification_date"
                            class="crm-form-input" />
                    </div>
                </div>
                <div class="crm-modal-footer">
                    <button type="button" @click="closeModal('loan.prequalification.edit')"
                        class="crm-btn-secondary">Cancel</button>
                    <button type="submit" class="crm-btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\partials\pre-qualification-form-modal.blade.php ENDPATH**/ ?>