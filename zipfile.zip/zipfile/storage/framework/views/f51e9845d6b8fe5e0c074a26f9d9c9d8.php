<?php
    $sortStart = $canManageLoanRecords ? 1 : 0;
?>
<div class="crm-table-wrap">
    <table class="crm-table crm-table-center" data-sortable-table="true">
        <thead>
            <tr>
                <?php if($canManageLoanRecords): ?>
                    <th></th>
                <?php endif; ?>
                <th data-sort-index="<?php echo e($sortStart); ?>" class="w-[20%]"><span class="crm-sort-btn">Project
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 1); ?>"><span class="crm-sort-btn">Client
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 2); ?>"><span class="crm-sort-btn">Loan Officer
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 3); ?>"><span class="crm-sort-btn">Approved Bank
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 4); ?>"><span class="crm-sort-btn">Banker
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 5); ?>" data-sort-type="number"><span class="crm-sort-btn">Applied
                        Amount (RM)<span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 6); ?>" data-sort-type="number"><span class="crm-sort-btn">Approved
                        Amount (RM)<span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 11); ?>" data-sort-type="number"><span class="crm-sort-btn">Approval
                        Deviation (%) <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 7); ?>" data-sort-type="number"><span class="crm-sort-btn">Interest
                        Rate <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 8); ?>"><span class="crm-sort-btn">Lock-in Period
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 9); ?>"><span class="crm-sort-btn">MRTA / MLTA
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 10); ?>" class="w-[8%]"><span class="crm-sort-btn">Special
                        Conditions
                        <span data-sort-indicator></span></span></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $approvedSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $deal = $submission->deal;
                    $hasRecord = !(
                        is_null($submission->applied_amount) &&
                        is_null($submission->approved_amount) &&
                        is_null($submission->interest_rate) &&
                        is_null($submission->lock_in_period) &&
                        is_null($submission->mrta_mlta) &&
                        is_null($submission->special_conditions)
                    );
                    $analysisPayload = [
                        'deal_id' => $deal?->id,
                        'loan_id' => $submission->loan_id,
                        'has_record' => $hasRecord,
                        'approved_bank' => $submission->approved_bank ?? $submission->bank_name,
                        'applied_amount' => $submission->applied_amount,
                        'approved_amount' => $submission->approved_amount,
                        'interest_rate' => $submission->interest_rate,
                        'lock_in_period' => $submission->lock_in_period,
                        'mrta_mlta' => $submission->mrta_mlta,
                        'special_conditions' => $submission->special_conditions,
                        'approval_deviation_percentage' => $submission->approval_deviation_percentage,
                    ];
                ?>
                <tr>
                    <?php if($canManageLoanRecords): ?>
                        <td>
                            <button type="button" data-analysis='<?php echo json_encode($analysisPayload, 15, 512) ?>'
                                @click="editDeal = JSON.parse($el.dataset.analysis); openModal('loan.approval.edit')"
                                class="crm-action-btn">
                                <i class="fa-solid <?php echo e($hasRecord ? 'fa-pen-to-square' : 'fa-plus'); ?>"></i>
                            </button>
                        </td>
                    <?php endif; ?>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->deal_id ?? ''))); ?>">
                        <button type="button" class="truncate text-indigo-600 hover:underline"
                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'loan.approval.detail', <?php echo \Illuminate\Support\Js::from($submission->loan_id)->toHtml() ?>)">
                            <?php echo e($deal->deal_id); ?>:
                        </button><br>
                        <?php echo e($deal->project_name); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->client?->name ?? ''))); ?>">
                        <?php echo e($deal->client?->name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->loanOfficer?->name ?? ''))); ?>">
                        <?php echo e($deal->loanOfficer?->name ?? '-'); ?></td>
                    <td
                        data-sort-value="<?php echo e(strtolower((string) ($submission->approved_bank ?? ($submission->bank_name ?? '')))); ?>">
                        <b><?php echo e($submission->approved_bank ?? ($submission->bank_name ?? '-')); ?></b>
                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($submission->banker_contact ?? ''))); ?>">
                        <?php echo e($submission->banker_contact ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e((float) ($submission->applied_amount ?? 0)); ?>">
                        <?php echo e(number_format($submission->applied_amount, 2)); ?></td>
                    <td data-sort-value="<?php echo e((float) ($submission->approved_amount ?? 0)); ?>">
                        <?php echo e(number_format($submission->approved_amount, 2)); ?></td>
                    <td data-sort-value="<?php echo e((float) ($submission->approval_deviation_percentage ?? 0)); ?>">
                        <?php echo e($submission->approval_deviation_percentage ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e((float) ($submission->interest_rate ?? 0)); ?>">
                        <?php echo e($submission->interest_rate ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($submission->lock_in_period ?? ''))); ?>">
                        <?php echo e($submission->lock_in_period ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($submission->mrta_mlta ?? ''))); ?>">
                        <?php echo e($submission->mrta_mlta ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($submission->special_conditions ?? ''))); ?>">
                        <?php echo e($submission->special_conditions ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($canManageLoanRecords ? '13' : '12'); ?>" class="crm-table-empty">
                        No approved loans found.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($approvedSubmissions->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\partials\approval-analysis-table.blade.php ENDPATH**/ ?>