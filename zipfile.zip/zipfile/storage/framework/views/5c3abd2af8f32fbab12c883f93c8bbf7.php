<?php
    $sortStart = $canManageLoanRecords ? 1 : 0;
?>
<div class="crm-table-wrap">
    <table class="crm-table crm-table-center" data-sortable-table="true">
        <thead>
            <tr>
                <?php if($canManageLoanRecords): ?>
                    <th></th>
                <?php endif; ?>
                <th data-sort-index="<?php echo e($sortStart); ?>" class="w-[15%]"><span class="crm-sort-btn">Project
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 1); ?>" class="w-[12%]"><span class="crm-sort-btn">Client
                        <span data-sort-indicator></span></span>
                </th>
                <th data-sort-index="<?php echo e($sortStart + 2); ?>"><span class="crm-sort-btn">Loan Officer
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 3); ?>" data-sort-type="date"><span class="crm-sort-btn">First
                        Disbursement Date <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 4); ?>" data-sort-type="date"><span class="crm-sort-btn">Full
                        Disbursement Date <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 5); ?>" data-sort-type="date"><span class="crm-sort-btn">SPA
                        Completion Date <span data-sort-indicator></span></span></th>
                <th data-sort-index="<?php echo e($sortStart + 6); ?>" data-sort-type="date"><span class="crm-sort-btn">Client
                        Notification Date <span data-sort-indicator></span></span></th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $approvedSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $deal = $submission->deal;
                    $hasDisbursement = !(
                        is_null($submission->first_disbursement_date) &&
                        is_null($submission->full_disbursement_date) &&
                        is_null($submission->spa_completion_date) &&
                        is_null($submission->client_notification_date)
                    );
                    $disbursementPayload = [
                        'deal_id' => $deal?->id,
                        'loan_id' => $submission->loan_id,
                        'has_record' => $hasDisbursement,
                        'first_disbursement_date' => optional($submission->first_disbursement_date)->format('Y-m-d'),
                        'full_disbursement_date' => optional($submission->full_disbursement_date)->format('Y-m-d'),
                        'spa_completion_date' => optional($submission->spa_completion_date)->format('Y-m-d'),
                        'client_notification_date' => optional($submission->client_notification_date)->format('Y-m-d'),
                    ];
                ?>
                <tr>
                    <?php if($canManageLoanRecords): ?>
                        <td>
                            <button type="button" data-disbursement='<?php echo json_encode($disbursementPayload, 15, 512) ?>'
                                @click="editDeal = JSON.parse($el.dataset.disbursement); openModal('loan.disbursement.edit')"
                                class="crm-action-btn">
                                <i class="fa-solid <?php echo e($hasDisbursement ? 'fa-pen-to-square' : 'fa-plus'); ?>"></i>
                            </button>
                        </td>
                    <?php endif; ?>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->deal_id ?? ''))); ?>">
                        <button type="button" class="truncate text-indigo-600 hover:underline"
                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'loan.disbursement.detail', <?php echo \Illuminate\Support\Js::from($submission->loan_id)->toHtml() ?>)">
                            <?php echo e($deal->deal_id); ?>:
                        </button><br>
                        <?php echo e($deal->project_name); ?>

                    </td>
                    <td class="col-left" data-sort-value="<?php echo e(strtolower((string) ($deal->client?->name ?? ''))); ?>">
                        <?php echo e($deal->client?->name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->loanOfficer?->name ?? ''))); ?>">
                        <?php echo e($deal->loanOfficer?->name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(optional($submission->first_disbursement_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date">
                        <?php echo e(optional($submission->first_disbursement_date)->format('d M Y') ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(optional($submission->full_disbursement_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date">
                        <?php echo e(optional($submission->full_disbursement_date)->format('d M Y') ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(optional($submission->spa_completion_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date">
                        <?php echo e(optional($submission->spa_completion_date)->format('d M Y') ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(optional($submission->client_notification_date)->format('Y-m-d') ?? ''); ?>"
                        class="crm-table-date">
                        <?php echo e(optional($submission->client_notification_date)->format('d M Y') ?? '-'); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($canManageLoanRecords ? '8' : '7'); ?>" class="crm-table-empty">
                        No approved loans found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($approvedSubmissions->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\loans\partials\disbursement-table.blade.php ENDPATH**/ ?>