<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'crm-btn-danger'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\danger-button.blade.php ENDPATH**/ ?>