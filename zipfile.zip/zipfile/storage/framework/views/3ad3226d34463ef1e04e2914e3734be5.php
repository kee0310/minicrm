<div class="crm-table-wrap">
    <table class="crm-table crm-table-center" data-sortable-table="true">
        <thead>
            <tr>
                <th></th>
                <th data-sort-index="2" class="col-left"><span class="crm-sort-btn">Project
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="1" class="col-left"><span class="crm-sort-btn">Lead
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="3" data-sort-type="number"><span class="crm-sort-btn">Selling Price
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="4" data-sort-type="number"><span class="crm-sort-btn">Commission
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="5"><span class="crm-sort-btn">Stage
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="6"><span class="crm-sort-btn">Salesperson
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="7"><span class="crm-sort-btn">Leader
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="8" data-sort-type="date"><span class="crm-sort-btn">Created
                        <span data-sort-indicator></span></span></th>
                <th></th>
            </tr>
        </thead>
        <tbody class="whitespace-nowrap">
            <?php $__empty_1 = true; $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php
                            $dealPayload = [
                                'id' => $deal->id,
                                'lead_id' => $deal->lead_id,
                                'salesperson_id' => $deal->salesperson_id,
                                'project_name' => $deal->project_name,
                                'developer' => $deal->developer,
                                'unit_number' => $deal->unit_number,
                                'selling_price' => $deal->selling_price,
                                'commission_percentage' => $deal->commission_percentage,
                                'commission_amount' => $deal->commission_amount,
                                'booking_fee' => $deal->booking_fee,
                                'spa_date' => optional($deal->spa_date)->format('Y-m-d'),
                                'pipeline' => $deal->pipeline?->value,
                                'pipeline_locked' => $deal->pipeline?->isLockedForManualEdit() ?? false,
                            ];
                        ?>
                        <button type="button" class="crm-action-btn" data-deal='<?php echo json_encode($dealPayload, 15, 512) ?>'
                            @click="openEditDeal(JSON.parse($el.dataset.deal))">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->deal_id ?? ''))); ?>" class="col-left">
                        <button type="button" class="truncate text-indigo-600 hover:underline"
                            @click="openLoanDetail(<?php echo e($deal->id); ?>, 'deal.detail')">
                            <?php echo e($deal->deal_id); ?>:
                        </button><br>
                        <?php echo e($deal->project_name); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->lead_name ?? ''))); ?>" class="col-left">
                        <?php echo e($deal->lead_name ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e((float) $deal->selling_price); ?>">
                        <?php echo e(number_format($deal->selling_price, 2)); ?></td>
                    <td data-sort-value="<?php echo e((float) $deal->commission_amount); ?>">
                        <?php echo e(number_format($deal->commission_amount, 2)); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $deal->pipeline?->value)); ?>">
                        <span class="<?php echo e($deal->pipeline->badge()); ?>">
                            <?php echo e($deal->pipeline->value); ?>

                        </span>
                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->salesperson_name ?? ''))); ?>">
                        <?php echo e($deal->salesperson_name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($deal->leader_name ?? ''))); ?>">
                        <?php echo e($deal->leader_name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(optional($deal->created_at)->format('Y-m-d')); ?>" class="crm-table-date">
                        <?php echo e(optional($deal->created_at)->format('Y-m-d')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('deals.destroy', $deal)); ?>" class="inline"
                            data-confirm="Confirm to delete deal <?php echo e($deal->project_name); ?>?">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="crm-action-btn-danger">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="crm-table-empty">No deals found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($deals->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\deals\partials\deals-table.blade.php ENDPATH**/ ?>