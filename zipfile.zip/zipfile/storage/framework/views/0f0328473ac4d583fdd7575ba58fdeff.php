<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'crm-btn-secondary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\secondary-button.blade.php ENDPATH**/ ?>