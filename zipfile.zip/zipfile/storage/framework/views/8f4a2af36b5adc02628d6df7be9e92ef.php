<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Deals')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <section class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            <article class="crm-kpi">
                <p class="crm-kpi-label">Total Deals</p>
                <p class="mt-2 text-2xl font-semibold text-slate-900"><?php echo e(number_format($summary['total'] ?? 0)); ?></p>
            </article>
            <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $key = strtolower(str_replace(' ', '_', $stage)); ?>
                <article class="crm-kpi">
                    <p class="crm-kpi-label"><?php echo e($stage); ?></p>
                    <p
                        class="mt-2 text-2xl font-semibold <?php echo e(strtolower($stage) === 'completed' ? 'text-green-600' : 'text-slate-900'); ?>"">
                        <?php echo e(number_format($summary[$key] ?? 0)); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="text-gray-900" x-data="loanPageState({
                dealFormOpen: false,
                dealFormMode: 'create',
                canEditSalesperson: <?php echo \Illuminate\Support\Js::from(auth()->user()?->hasRole(\App\Enums\RoleEnum::ADMIN->value) || auth()->user()?->hasRole(\App\Enums\RoleEnum::LEADER->value))->toHtml() ?>,
                currentUserId: <?php echo \Illuminate\Support\Js::from((int) (auth()->id() ?? 0))->toHtml() ?>,
                defaultDealPipeline: <?php echo \Illuminate\Support\Js::from($pipelines[0]->value ?? '')->toHtml() ?>,
                dealForm: {},
                searchTerm: <?php echo \Illuminate\Support\Js::from(request('search', ''))->toHtml() ?>,
                stageFilter: <?php echo \Illuminate\Support\Js::from(request('stage', ''))->toHtml() ?>,
                ...tableListState({
                    endpoint: '<?php echo e(route('deals.index')); ?>',
                    filters: { stageFilter: 'stage' },
                }),
                emptyDealForm() {
                    const defaultSalespersonId = this.salespersonOptions.some(user => Number(user.id) === Number(this.currentUserId))
                        ? String(this.currentUserId)
                        : String(this.salespersonOptions[0]?.id ?? '');
                    return {
                        id: null,
                        pipeline: this.defaultDealPipeline,
                        lead_id: '',
                        project_name: '',
                        developer: '',
                        unit_number: '',
                        selling_price: '',
                        commission_percentage: '',
                        commission_amount: '',
                        booking_fee: '',
                        spa_date: '',
                        pipeline_locked: false,
                        salesperson_id: defaultSalespersonId,
                    };
                },
                salespersonOptions: <?php echo \Illuminate\Support\Js::from($salespersons->map(fn($user) => ['id' => $user->id, 'name' => $user->name])->values())->toHtml() ?>,
                openCreateDeal() {
                    this.dealFormMode = 'create';
                    this.dealForm = this.emptyDealForm();
                    this.dealFormOpen = true;
                    this.$nextTick(() => {
                        this.recalc();
                        this.toggleBookingAndSpa();
                    });
                },
                openEditDeal(deal) {
                    this.dealFormMode = 'edit';
                    this.dealForm = { ...this.emptyDealForm(), ...deal };
                    this.dealFormOpen = true;
                    this.$nextTick(() => {
                        this.recalc();
                        this.toggleBookingAndSpa();
                    });
                },
                toggleBookingAndSpa() {
                    const pipeline = this.dealForm?.pipeline;
                    const bookingGroup = document.getElementById('booking_fee_group');
                    const bookingInput = document.getElementById('booking_fee');
                    const spaGroup = document.getElementById('spa_date_group');
                    const spaInput = document.getElementById('spa_date');
                    const hideBoth = pipeline === 'Lead' || pipeline === 'Viewing';
                    const hideSpaOnly = pipeline === 'Booking';
                    const showBooking = !hideBoth;
                    const showSpa = !hideBoth && !hideSpaOnly;
                    const needsBooking = pipeline === 'Booking' || pipeline === 'SPA Signed';
                    const needsSpa = pipeline === 'SPA Signed';
                    if (bookingGroup && bookingInput) {
                        bookingGroup.style.display = showBooking ? '' : 'none';
                        bookingInput.required = needsBooking;
                    }
                    if (spaGroup && spaInput) {
                        spaGroup.style.display = showSpa ? '' : 'none';
                        spaInput.required = needsSpa;
                    }
                },
                recalc() {
                    const priceInput = document.getElementById('selling_price');
                    const pctInput = document.getElementById('commission_percentage');
                    const amountInput = document.getElementById('commission_amount');
                    const price = parseFloat(priceInput?.value || 0) || 0;
                    const pct = parseFloat(pctInput?.value || 0) || 0;
                    if (amountInput) amountInput.value = (price * pct / 100).toFixed(2);
                    if (this.dealForm) {
                        this.dealForm.commission_amount = amountInput?.value;
                    }
                }
            })">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-medium"><?php echo e(__('List of deals')); ?></h3>
                </div>

                <div class="crm-filter-block">
                    <div class="crm-filter-toolbar">
                        <?php if (isset($component)) { $__componentOriginal240eade74da28b909c777a016dde0287 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal240eade74da28b909c777a016dde0287 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-search-row','data' => ['model' => 'searchTerm','placeholder' => 'Search project or lead...','requestValue' => request('search', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-search-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => 'searchTerm','placeholder' => 'Search project or lead...','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('search', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $attributes = $__attributesOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__attributesOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $component = $__componentOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__componentOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
                        <button type="button"
                            @click="openCreateDeal()"
                            class="crm-create-btn">
                            <?php echo e(__('Create Deal')); ?>

                        </button>
                    </div>
                    <div class="crm-filter-tabs-scroll scrollbar-hide">
                        <div class="crm-filter-tabs">
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'stageFilter','value' => '','label' => 'All','requestValue' => request('stage', ''),'all' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'stageFilter','value' => '','label' => 'All','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('stage', '')),'all' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                            <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'stageFilter','value' => $stage,'label' => $stage,'requestValue' => request('stage', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'stageFilter','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stage),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stage),'request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('stage', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div id="live-table-container" @click="handleTableClick($event)"><?php echo $__env->make('deals.partials.deals-table', ['deals' => $deals], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <?php echo $__env->make('deals.partials.deal-detail-modal', ['modalKey' => 'deal.detail'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('deals.partials.deal-form-modals', [
                    'pipelines' => $pipelines,
                    'leads' => $leads,
                    'salespersons' => $salespersons,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\deals\index.blade.php ENDPATH**/ ?>