﻿<div class="crm-table-wrap">
    <table class="crm-table" data-sortable-table="true">
        <thead>
            <tr>
                <th class="w-[50px]"><span class="crm-sort-btn pointer-events-none">No.</span></th>
                <th data-sort-index="1"><span class="crm-sort-btn">Name
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="2"><span class="crm-sort-btn">Email
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="3"><span class="crm-sort-btn">Phone
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="4" data-sort-type="number"><span class="crm-sort-btn">Age
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="5"><span class="crm-sort-btn">Occupation
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="6"><span class="crm-sort-btn">Company
                        <span data-sort-indicator></span></span></th>
            </tr>
        </thead>
        <tbody class="whitespace-nowrap">
            <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $client->name)); ?>" class="text-gray-900"
                        style="text-align: left; padding-left: 20px">
                        <a href="<?php echo e(route('clients.show', $client->id)); ?>" class="text-indigo-600 hover:underline">
                            <?php echo e($client->name); ?>

                        </a>
                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) $client->email)); ?>"><?php echo e($client->email); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $client->phone)); ?>"><?php echo e($client->phone); ?></td>
                    <td data-sort-value="<?php echo e($client->age ?? ''); ?>"><?php echo e($client->age ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $client->occupation)); ?>">
                        <?php echo e($client->occupation ?? '-'); ?>

                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) $client->company)); ?>">
                        <?php echo e($client->company ?? '-'); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="crm-table-empty">No clients found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($clients->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\clients\partials\clients-table.blade.php ENDPATH**/ ?>