<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Leads')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">

        <section class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            <article class="crm-kpi">
                <p class="crm-kpi-label">Total Leads</p>
                <p class="mt-2 text-2xl font-semibold text-slate-900"><?php echo e(number_format($summary['total'] ?? 0)); ?></p>
            </article>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $key = strtolower(str_replace(' ', '_', $status));
                ?>
                <article class="crm-kpi">
                    <p class="crm-kpi-label"><?php echo e($status); ?></p>
                    <p
                        class="mt-2 text-2xl font-semibold <?php echo e(strtolower($status) === 'lost' ? 'text-red-600' : (strtolower($status) === 'deal' ? 'text-green-600' : 'text-slate-900')); ?>">
                        <?php echo e(number_format($summary[$key] ?? 0)); ?>

                    </p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <?php
            $leadSourceOptions = [
                'Facebook',
                'Friend Referral',
                'Exhibition/Fair',
                'Company Assigned',
                'Old Client Referral',
            ];
        ?>
        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="text-gray-900" x-data="{
                leadFormOpen: false,
                leadFormMode: 'create',
                currentUserId: <?php echo \Illuminate\Support\Js::from((int) (auth()->id() ?? 0))->toHtml() ?>,
                canEditSalesperson: <?php echo \Illuminate\Support\Js::from(auth()->user()?->hasRole(\App\Enums\RoleEnum::ADMIN->value) || auth()->user()?->hasRole(\App\Enums\RoleEnum::LEADER->value))->toHtml() ?>,
                defaultLeadStatus: <?php echo \Illuminate\Support\Js::from($statuses[0] ?? 'New')->toHtml() ?>,
                leadForm: {},
                initialLeadFormOpen: <?php echo \Illuminate\Support\Js::from($errors->any())->toHtml() ?>,
                initialLeadFormMode: <?php echo \Illuminate\Support\Js::from(old('_method') === 'PUT' ? 'edit' : 'create')->toHtml() ?>,
                initialLeadForm: <?php echo \Illuminate\Support\Js::from([
                    'id' => old('lead_id'),
                    'name' => old('name'),
                    'email' => old('email'),
                    'phone' => old('phone'),
                    'source' => old('source'),
                    'salesperson_id' => old('salesperson_id'),
                    'status' => old('status'),
                    'age' => old('age'),
                    'ic_passport' => old('ic_passport'),
                    'occupation' => old('occupation'),
                    'company' => old('company'),
                    'monthly_income' => old('monthly_income'),
                    'working_years' => old('working_years'),
                    'fixed_income' => old('fixed_income'),
                ])->toHtml() ?>,
                searchTerm: <?php echo \Illuminate\Support\Js::from(request('search', ''))->toHtml() ?>,
                statusFilter: <?php echo \Illuminate\Support\Js::from(request('status', ''))->toHtml() ?>,
                ...tableListState({
                    endpoint: '<?php echo e(route('leads.index')); ?>',
                    filters: { statusFilter: 'status' },
                }),
                init() {
                    this.leadForm = this.emptyLeadForm();
                    if (this.initialLeadFormOpen) {
                        this.leadFormMode = this.initialLeadFormMode;
                        this.leadForm = { ...this.leadForm, ...this.initialLeadForm };
                        this.leadFormOpen = true;
                    }
                    this.$nextTick(() => this.toggleDealFields());
                },
                emptyLeadForm() {
                    const defaultSalespersonId = this.salespersonOptions.some(user => Number(user.id) === Number(this.currentUserId))
                        ? String(this.currentUserId)
                        : String(this.salespersonOptions[0]?.id ?? '');
                    return {
                        id: null,
                        name: '',
                        email: '',
                        phone: '',
                        source: '<?php echo e($leadSourceOptions[0] ?? ''); ?>',
                        salesperson_id: defaultSalespersonId,
                        status: this.defaultLeadStatus,
                        age: '',
                        ic_passport: '',
                        occupation: '',
                        company: '',
                        monthly_income: '',
                        working_years: '',
                        fixed_income: '',
                    };
                },
                salespersonOptions: <?php echo \Illuminate\Support\Js::from($salespersons->map(fn($user) => ['id' => $user->id, 'name' => $user->name])->values())->toHtml() ?>,
                openCreateLead() {
                    this.leadFormMode = 'create';
                    this.leadForm = this.emptyLeadForm();
                    this.leadFormOpen = true;
                    this.$nextTick(() => this.toggleDealFields());
                },
                openEditLead(lead) {
                    this.leadFormMode = 'edit';
                    this.leadForm = { ...this.emptyLeadForm(), ...lead };
                    this.leadFormOpen = true;
                    this.$nextTick(() => this.toggleDealFields());
                },
                toggleDealFields() {
                    const wrap = document.getElementById('lead_deal_fields');
                    const status = this.leadForm?.status;
                    if (wrap) wrap.style.display = status === 'Deal' ? '' : 'none';
                }
            }">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-medium"><?php echo e(__('List of leads')); ?></h3>
                </div>

                <div class="crm-filter-block">
                    <div class="crm-filter-toolbar">
                        <?php if (isset($component)) { $__componentOriginal240eade74da28b909c777a016dde0287 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal240eade74da28b909c777a016dde0287 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-search-row','data' => ['model' => 'searchTerm','placeholder' => 'Search name, email or phone...','requestValue' => request('search', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-search-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['model' => 'searchTerm','placeholder' => 'Search name, email or phone...','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('search', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $attributes = $__attributesOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__attributesOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal240eade74da28b909c777a016dde0287)): ?>
<?php $component = $__componentOriginal240eade74da28b909c777a016dde0287; ?>
<?php unset($__componentOriginal240eade74da28b909c777a016dde0287); ?>
<?php endif; ?>
                        <button class="crm-create-btn sm:w-full" type="button"
                            @click="openCreateLead()">
                            <?php echo e(__('Create Lead')); ?>

                        </button>
                    </div>
                    <div class="crm-filter-tabs-scroll scrollbar-hide">
                        <div class="crm-filter-tabs">
                            <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'statusFilter','value' => '','label' => 'All','requestValue' => request('status', ''),'all' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'statusFilter','value' => '','label' => 'All','request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('status', '')),'all' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                            <?php if(!empty($statuses)): ?>
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if (isset($component)) { $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.filter-tab-button','data' => ['stateKey' => 'statusFilter','value' => $s,'label' => $s,'requestValue' => request('status', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filter-tab-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['state-key' => 'statusFilter','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s),'request-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request('status', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $attributes = $__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__attributesOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983)): ?>
<?php $component = $__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983; ?>
<?php unset($__componentOriginald0b733fe0b44aeb4baa77ad6bff7d983); ?>
<?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div id="live-table-container" @click="handleTableClick($event)"><?php echo $__env->make('leads.partials.leads-table', ['leads' => $leads], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <?php echo $__env->make('leads.partials.lead-form-modals', [
                    'leadSourceOptions' => $leadSourceOptions,
                    'salespersons' => $salespersons,
                    'statuses' => $statuses,
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


            </div>
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\leads\index.blade.php ENDPATH**/ ?>