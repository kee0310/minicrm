<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'stateKey',
    'value' => '',
    'requestValue' => '',
    'label' => '',
    'all' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'stateKey',
    'value' => '',
    'requestValue' => '',
    'label' => '',
    'all' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $targetValue = (string) $value;
    $requestedValue = (string) $requestValue;
    $baseClass = $all ? 'crm-filter-tab crm-filter-tab-all' : 'crm-filter-tab crm-filter-tab-stage';
?>

<button type="button"
    @click="
        $el.closest('.crm-filter-tabs')?.querySelectorAll('.crm-filter-tab').forEach((tab) => tab.classList.remove('crm-filter-tab-active'));
        $el.classList.add('crm-filter-tab-active');
        <?php echo e($stateKey); ?> = <?php echo \Illuminate\Support\Js::from($targetValue)->toHtml() ?>;
        refreshList();
    "
    :class="<?php echo e($stateKey); ?> === <?php echo \Illuminate\Support\Js::from($targetValue)->toHtml() ?> ? 'crm-filter-tab-active' : 'crm-filter-tab-inactive'"
    class="<?php echo e($baseClass); ?> <?php echo e($requestedValue === $targetValue ? 'crm-filter-tab-active' : 'crm-filter-tab-inactive'); ?>">
    <?php echo e($label); ?>

</button>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\components\filter-tab-button.blade.php ENDPATH**/ ?>