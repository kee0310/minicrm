<div class="crm-table-wrap">
    <table class="crm-table" data-sortable-table="true">
        <thead>
            <tr>
                <th></th>
                <th data-sort-index="1"><span class="crm-sort-btn">Name
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="2"><span class="crm-sort-btn">Email
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="3"><span class="crm-sort-btn">Phone
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="4"><span class="crm-sort-btn">Source
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="5"><span class="crm-sort-btn">Salesperson
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="6"><span class="crm-sort-btn">Leader
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="7"><span class="crm-sort-btn">Status
                        <span data-sort-indicator></span></span></th>
                <th data-sort-index="8" data-sort-type="date"><span class="crm-sort-btn">Created Date
                        <span data-sort-indicator></span></span></th>
                <th></th>
            </tr>
        </thead>
        <tbody class="whitespace-nowrap">
            <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <?php
                            $leadPayload = [
                                'id' => $lead->id,
                                'name' => $lead->name,
                                'email' => $lead->email,
                                'phone' => $lead->phone,
                                'source' => $lead->source,
                                'salesperson_id' => $lead->salesperson_id,
                                'status' => $lead->status?->value,
                                'age' => $lead->age,
                                'ic_passport' => $lead->ic_passport,
                                'occupation' => $lead->occupation,
                                'company' => $lead->company,
                                'working_years' => $lead->working_years,
                                'monthly_income' => $lead->monthly_income,
                                'fixed_income' => $lead->fixed_income,
                            ];
                        ?>
                        <button type="button" class="crm-action-btn" data-lead='<?php echo json_encode($leadPayload, 15, 512) ?>'
                            @click="openEditLead(JSON.parse($el.dataset.lead))">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                    </td>
                    <td data-sort-value="<?php echo e(strtolower((string) $lead->name)); ?>" class="text-sm text-gray-900">
                        <?php echo e($lead->name); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $lead->email)); ?>"><?php echo e($lead->email); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $lead->phone)); ?>"><?php echo e($lead->phone); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $lead->source)); ?>"><?php echo e($lead->source); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($lead->salesperson_name ?? ''))); ?>">
                        <?php echo e($lead->salesperson_name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) ($lead->leader_name ?? ''))); ?>">
                        <?php echo e($lead->leader_name ?? '-'); ?></td>
                    <td data-sort-value="<?php echo e(strtolower((string) $lead->status?->value)); ?>">
                        <span class="<?php echo e($lead->status->badge()); ?>">
                            <?php echo e($lead->status->value); ?>

                        </span>
                    </td>
                    <td data-sort-value="<?php echo e(optional($lead->created_at)->format('Y-m-d')); ?>" class="crm-table-date">
                        <?php echo e(optional($lead->created_at)->format('Y-m-d') ?? '-'); ?>

                    </td>
                    <td>
                        <?php if($lead->status !== \App\Enums\LeadStatusEnum::DEAL): ?>
                            <form method="POST" action="<?php echo e(route('leads.destroy', $lead)); ?>" class="inline"
                                data-preserve-list-state
                                data-confirm="Confirm to delete lead <?php echo e($lead->name); ?>?">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="crm-action-btn-danger">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="crm-table-empty">No leads found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($leads->onEachSide(1)->links()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\minicrm\resources\views\leads\partials\leads-table.blade.php ENDPATH**/ ?>